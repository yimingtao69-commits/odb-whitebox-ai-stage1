# ODB White-Box AI — executable reference slice

这是一个可运行的第一阶段参考代码包，不是完整 ODB 工厂，也不包含第二阶段晶格运行时或第三阶段防越狱实现。

## 运行

需要 Python 3.11+，仅使用标准库：

```powershell
python tools/run_aaai27_1914_core_reproduction.py
```

脚本从 `product_teaching_demo/cases/july_1914_dynamic_fixture.json` 读取结构化状态、动作、条件和效果，执行确定性的 branch-and-prune replay，并生成可读 Markdown、完整 JSON 和摘要。

## 测试

```powershell
python -m unittest discover -s tests -p "test_*.py"
```

## 代码边界

- `historical_case_replay.py`：结构化状态/动作重放；
- `state_graph_core/`：稳定规范化和图标识辅助；
- `v04_compliance_hard_run.py`：受控对象状态电影样例；
- `july_1914_dynamic_fixture.json`：公开教学输入。

该包不声称实现自然语言端到端解析、生产级吞吐、主机防篡改、客户业务或完整行政内核。输入 fixture 是人工结构化的，不能被误读为自然语言解析实验。

## 许可证

本参考代码与随附理论材料沿用 `CC BY-NC 4.0`。它允许署名和非商业复制/改编，禁止商业使用。该许可证不是 OSI 软件许可证；如需商业许可，必须另行取得书面许可。

## 发布安全

包内不含客户数据、运行数据库、密钥、凭据、模型会话或私有日志。发布前请核对 `SHA256SUMS.txt`。
