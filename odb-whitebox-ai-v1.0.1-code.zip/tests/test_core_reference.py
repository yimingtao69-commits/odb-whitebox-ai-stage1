import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
DEMO = ROOT / "product_teaching_demo"
DICT = DEMO / "departments" / "lexicon_layer" / "dictionary_component"
TOOLS = ROOT / "tools"
sys.path.insert(0, str(DEMO))
sys.path.insert(0, str(DICT))
sys.path.insert(0, str(TOOLS))

from historical_case_replay import load_historical_case, run_historical_case_replay
from sample_warehouse.best_samples.v04_compliance_hard_run import build_v04_july1914_compliance_hard_run_response
from run_aaai27_1914_core_reproduction import DEFAULT_SCORE_WEIGHTS


class CoreReferenceAcceptance(unittest.TestCase):
    def test_structured_fixture_replays(self):
        case = load_historical_case(DEMO / "cases" / "july_1914_dynamic_fixture.json")
        result = run_historical_case_replay(case, score_weights=DEFAULT_SCORE_WEIGHTS)
        self.assertEqual(result.status, "completed")
        self.assertEqual(len(result.surviving_paths), 7)

    def test_v04_reference_movie_is_bounded_and_successful(self):
        result = build_v04_july1914_compliance_hard_run_response()
        self.assertTrue(result["ok"])
        self.assertEqual(result["worldline_set"]["worldline_count"], 16)

    def test_fixture_is_explicitly_structured(self):
        data = json.loads((DEMO / "cases" / "july_1914_dynamic_fixture.json").read_text(encoding="utf-8"))
        self.assertTrue(data["actions"])
        self.assertTrue(all("actor" in action and "effects" in action for action in data["actions"]))


if __name__ == "__main__":
    unittest.main()
