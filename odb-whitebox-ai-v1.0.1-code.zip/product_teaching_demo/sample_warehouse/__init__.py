"""Auditable sample warehouse."""

