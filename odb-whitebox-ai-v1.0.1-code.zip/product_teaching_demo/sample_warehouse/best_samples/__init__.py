"""Best preserved proof/regression samples."""

