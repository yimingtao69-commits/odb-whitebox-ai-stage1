from __future__ import annotations

"""V0.4 July 1914 compliance hard-run fixture.

This is a deliberately narrow "chooseable movie" fixture.  It does not claim to
enumerate the whole possibility space.  It hard-runs only the objects, domain
links, SVO operations, and branches named in the current V0.4 theory report.

The important output is not just one worldline id.  The route returns:

* an initial cross-section state board;
* every selected scene on a time axis;
* object states before and after each scene;
* a state diff/patch for each scene;
* available but unselected choices;
* a final settlement board.
"""

from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any


STATE_DIMENSIONS: tuple[dict[str, str], ...] = (
    {"id": "war_risk", "label": "战争风险"},
    {"id": "tension_trigger", "label": "紧张触发器"},
    {"id": "procedural_legitimacy", "label": "程序合法性"},
    {"id": "observer_role", "label": "观察/调停角色"},
    {"id": "geographic_access", "label": "地理可连接性"},
    {"id": "non_interference", "label": "不干涉状态"},
    {"id": "nationalist_separation", "label": "民族主义切割"},
    {"id": "original_worldline_gravity", "label": "原史实吸引子"},
)


@dataclass(frozen=True)
class V04LexiconSense:
    term: str
    pack: str
    pos: str
    slots: tuple[str, ...]
    state_effects: dict[str, Any]
    temporary: bool = True


@dataclass(frozen=True)
class V04Operation:
    operation_id: str
    scene_id: str
    source_stage: str
    s: str
    v: str
    o: str
    domain_pack: str
    derived_from: str
    selected: bool
    choice_prompt: str
    dependencies: tuple[str, ...] = ()
    state_delta: dict[str, dict[str, Any]] = field(default_factory=dict)
    branch_if_uncooperative: str = ""

    @property
    def svo(self) -> str:
        return f"{self.s} {self.v} {self.o}"


@dataclass(frozen=True)
class V04Branch:
    branch_id: str
    trigger: str
    selected: bool
    reason: str
    operations: tuple[str, ...]
    terminal_hint: str


def _initial_object_states() -> dict[str, dict[str, Any]]:
    return {
        "austria_hungary": {
            "display_name": "奥匈",
            "role": "main_object",
            "war_risk": "high",
            "tension_trigger": "ultimatum_available",
            "procedural_legitimacy": "contested",
            "military_irreversibility": "rising",
            "external_naval_interference_from_britain": "unknown",
            "austria_hungary_original_worldline_gravity": "strong",
        },
        "britain": {
            "display_name": "英国",
            "role": "external_observer_candidate",
            "british_observer_role": "not_requested",
            "british_non_interference": "unknown",
            "channel_access_to_continent": "available_but_not_used",
            "continental_order_responsibility": "uncommitted",
        },
        "serbia": {
            "display_name": "塞尔维亚",
            "role": "reply_object",
            "serbian_nationalist_separation": "not_forced",
            "procedural_position": "unresolved",
        },
        "italy": {
            "display_name": "意大利",
            "role": "alliance_credit_object",
            "italy_credit_visibility": "low",
            "adriatic_naval_conflict": "latent",
        },
        "russia": {
            "display_name": "俄国",
            "role": "mobilization_chain_object",
            "russian_clean_mobilization_point": "available_if_ah_attacks",
            "slavic_narrative_monopoly": "available",
        },
        "france": {
            "display_name": "法国",
            "role": "alliance_chain_object",
            "support_to_russia": "depends_on_british_position",
        },
        "germany": {
            "display_name": "德国",
            "role": "ally_backstop",
            "hardening_pressure": "latent",
        },
        "geography": {
            "display_name": "地理包",
            "role": "domain_package",
            "english_channel": "britain_continent_maritime_gate",
            "adriatic_sea": "italy_austria_hungary_naval_contact_zone",
            "britain_continent_link": "not_materialized",
            "adriatic_italy_ah_link": "not_materialized",
        },
        "central_hub": {
            "display_name": "中枢账房",
            "role": "dependency_ledger",
            "pending_dependencies": [],
            "expired_dependencies": [],
        },
        "world_tree": {
            "display_name": "世界树",
            "role": "settlement_manager",
            "terminal": "not_settled",
            "worldline_id": "",
        },
    }


def _fixture_senses() -> tuple[V04LexiconSense, ...]:
    return (
        V04LexiconSense(
            term="最后通牒",
            pack="diplomacy_crisis_pack",
            pos="noun",
            slots=("issuer", "receiver", "deadline"),
            state_effects={"tension_trigger": "increase", "war_risk": "increase"},
        ),
        V04LexiconSense(
            term="取消",
            pack="meta_operation_pack",
            pos="verb",
            slots=("subject", "object"),
            state_effects={"target_state_change": "canceled"},
        ),
        V04LexiconSense(
            term="延后",
            pack="temporal_pack",
            pos="verb",
            slots=("subject", "object", "delta_t_or_event_anchor"),
            state_effects={"trigger_timestamp": "shift_later"},
        ),
        V04LexiconSense(
            term="观察",
            pack="diplomacy_crisis_pack",
            pos="verb",
            slots=("observer", "case"),
            state_effects={"procedural_legitimacy": "increase", "escalation_speed": "decrease"},
        ),
        V04LexiconSense(
            term="英吉利海峡",
            pack="geography_pack",
            pos="noun",
            slots=("maritime_gate", "britain", "continent"),
            state_effects={"britain_can_monitor_continent": True},
        ),
        V04LexiconSense(
            term="亚得里亚海",
            pack="geography_pack",
            pos="noun",
            slots=("naval_contact_zone", "italy", "austria_hungary"),
            state_effects={"italy_austria_hungary_naval_contact": True},
        ),
        V04LexiconSense(
            term="不干涉",
            pack="diplomacy_crisis_pack",
            pos="verb",
            slots=("subject", "conflict"),
            state_effects={"external_interference": "canceled"},
        ),
        V04LexiconSense(
            term="切割",
            pack="political_legitimacy_pack",
            pos="verb",
            slots=("government", "network"),
            state_effects={
                "violent_nationalist_route": "decrease",
                "procedural_position": "forced_choice",
            },
        ),
    )


def _read_cross_section() -> dict[str, Any]:
    text = (
        "萨拉热窝刺杀后，奥匈以自身多维状态总和上升为根目标。"
        "本次符合性硬跑只允许使用当前 V0.4 报告中提及的对象、词、包和操作："
        "取消或延后最后通牒、请求英国观察、不越境不炮击不总动员、"
        "质询塞尔维亚和意大利、强迫塞尔维亚切割民族主义、"
        "依靠地理包连接英吉利海峡与奥匈外交场、连接亚得里亚海与意奥海战槽位，"
        "并生成英国不干涉意大利奥匈海战的状态。"
    )
    tokens = (
        "萨拉热窝刺杀",
        "奥匈",
        "最后通牒",
        "取消",
        "延后",
        "英国",
        "观察",
        "英吉利海峡",
        "意大利",
        "奥匈海战",
        "亚得里亚海",
        "不干涉",
        "塞尔维亚",
        "切割",
    )
    return {
        "stage": "cross_section_reading",
        "input_text": text,
        "tokens": list(tokens),
        "policy": "read_filter_is_wide_but_generation_filter_is_domain_bound",
    }


def _ingest_terms(tokens: tuple[str, ...], senses: tuple[V04LexiconSense, ...]) -> dict[str, Any]:
    by_term = {sense.term: sense for sense in senses}
    known = []
    temporary_new = []
    unknown = []
    aliases = {
        "英国": "britain",
        "奥匈": "austria_hungary",
        "奥匈海战": "adriatic_naval_conflict",
    }
    for token in tokens:
        if token in by_term:
            known.append(token)
        elif token in aliases or token in {"萨拉热窝刺杀", "塞尔维亚", "意大利"}:
            temporary_new.append(token)
        else:
            unknown.append(token)
    return {
        "stage": "temporary_ingestion",
        "known_senses": known,
        "temporary_terms": temporary_new,
        "unknown_terms": unknown,
        "runtime_policy": "temporary_terms_are_runtime_formal_for_this_compliance_run",
    }


def _generate_operations() -> tuple[V04Operation, ...]:
    return (
        V04Operation(
            operation_id="OP-001",
            scene_id="SC-01",
            source_stage="condition_operation_graph",
            s="奥匈",
            v="取消",
            o="最后通牒",
            domain_pack="diplomacy_crisis_pack",
            derived_from="最后通牒=紧张触发+；取消=取消该上升变化，而非制造紧张度-",
            selected=True,
            choice_prompt="奥匈如何处理最后通牒触发器？",
            state_delta={
                "austria_hungary": {
                    "tension_trigger": "ultimatum_canceled",
                    "war_risk": "not_increased_by_ultimatum",
                },
                "russia": {"russian_clean_mobilization_point": "weakened"},
            },
        ),
        V04Operation(
            operation_id="OP-002",
            scene_id="SC-01",
            source_stage="temporal_state_graph",
            s="奥匈",
            v="延后",
            o="最后通牒",
            domain_pack="temporal_pack",
            derived_from="延后=时间状态变化；trigger_timestamp 后移；本次不选，保留为待注释分支",
            selected=False,
            choice_prompt="奥匈如何处理最后通牒触发器？",
            dependencies=("DEP-TIME-001",),
            state_delta={
                "austria_hungary": {
                    "tension_trigger": "not_triggered_now_but_retained_later",
                    "trigger_timestamp": "requires_delta_t",
                }
            },
            branch_if_uncooperative="BR-temporal-stale",
        ),
        V04Operation(
            operation_id="OP-003",
            scene_id="SC-02",
            source_stage="person_graph",
            s="奥匈",
            v="请求",
            o="英国观察奥塞争端",
            domain_pack="diplomacy_crisis_pack",
            derived_from="观察=程序合法性+；英国作为外部观察对象由人图连接",
            selected=True,
            choice_prompt="奥匈是否把英国拉入观察/调停位置？",
            state_delta={
                "austria_hungary": {"procedural_legitimacy": "rising"},
                "britain": {
                    "british_observer_role": "requested",
                    "continental_order_responsibility": "invited",
                },
                "france": {"support_to_russia": "more_costly"},
            },
            branch_if_uncooperative="BR-britain-refuses-observer-role",
        ),
        V04Operation(
            operation_id="OP-004",
            scene_id="SC-03",
            source_stage="geography_pack",
            s="地理包",
            v="连接",
            o="英吉利海峡 → 英国 → 欧洲大陆 → 奥匈外交场",
            domain_pack="geography_pack",
            derived_from="英吉利海峡=英国与欧洲大陆的海上门；地理包只证明可连接，不推演政治必然性",
            selected=True,
            choice_prompt="英国观察请求能否落到地理可连接结构上？",
            state_delta={
                "geography": {"britain_continent_link": "available"},
                "britain": {"channel_access_to_continent": "available"},
            },
        ),
        V04Operation(
            operation_id="OP-005",
            scene_id="SC-04",
            source_stage="geography_pack",
            s="地理包",
            v="连接",
            o="亚得里亚海 → 意大利 / 奥匈海军接触区",
            domain_pack="geography_pack",
            derived_from="亚得里亚海=意大利与奥匈海上接触区；为意大利奥匈海战状态提供地理槽位",
            selected=True,
            choice_prompt="意大利奥匈海战状态是否有地理槽位？",
            state_delta={
                "geography": {"adriatic_italy_ah_link": "available"},
                "italy": {"adriatic_naval_conflict": "possible"},
            },
        ),
        V04Operation(
            operation_id="OP-006",
            scene_id="SC-05",
            source_stage="branch_operation_graph",
            s="英国",
            v="不干涉",
            o="意大利奥匈海战",
            domain_pack="diplomacy_crisis_pack",
            derived_from="不干涉=取消外部干涉状态变化；依赖英国观察角色、海峡连接、亚得里亚海战槽位均已可读",
            selected=True,
            choice_prompt="英国面对意大利奥匈海战槽位如何表态？",
            state_delta={
                "britain": {
                    "british_non_interference": "declared_for_italy_ah_naval_conflict"
                },
                "italy": {"adriatic_naval_conflict": "not_british_interfered"},
                "austria_hungary": {"external_naval_interference_from_britain": "canceled"},
            },
            branch_if_uncooperative="BR-britain-interferes",
        ),
        V04Operation(
            operation_id="OP-007",
            scene_id="SC-06",
            source_stage="political_legitimacy_graph",
            s="奥匈",
            v="要求",
            o="塞尔维亚政府切割极端民族主义网络",
            domain_pack="political_legitimacy_pack",
            derived_from="切割=暴力民族主义路线下降；塞尔维亚进入承认/拒绝两难",
            selected=True,
            choice_prompt="奥匈如何改变塞尔维亚程序位置？",
            state_delta={
                "serbia": {
                    "serbian_nationalist_separation": "forced_choice",
                    "procedural_position": "dilemma",
                },
                "austria_hungary": {"procedural_legitimacy": "rising"},
            },
            branch_if_uncooperative="BR-serbia-refuses-separation",
        ),
        V04Operation(
            operation_id="OP-008",
            scene_id="SC-07",
            source_stage="world_tree_terminal",
            s="世界树",
            v="结算",
            o="奥匈走出原史实吸引子的一条符合性世界线",
            domain_pack="world_tree_runtime",
            derived_from="关键状态拼齐：通牒触发取消、英国观察被请求、地理连接成立、英国不干涉意奥海战、塞尔维亚切割困境成立",
            selected=True,
            choice_prompt="世界树是否结算这条符合性世界线？",
            state_delta={
                "austria_hungary": {
                    "austria_hungary_original_worldline_gravity": "escaped_in_this_fixture",
                    "terminal_state": "non_original_worldline_terminal",
                },
                "world_tree": {
                    "terminal": "WL-COMP-001",
                    "worldline_id": "WL-COMP-001",
                },
            },
        ),
    )


def _branches() -> tuple[V04Branch, ...]:
    return (
        V04Branch(
            branch_id="BR-temporal-stale",
            trigger="延后最后通牒但 Δt 未补",
            selected=False,
            reason="本次硬跑选择 OP-001 取消最后通牒；延后分支只挂账，不结算为完成。",
            operations=("OP-002",),
            terminal_hint="若长期不补 Δt，则该分支 stale/expired。",
        ),
        V04Branch(
            branch_id="BR-britain-refuses-observer-role",
            trigger="英国拒绝观察",
            selected=False,
            reason="本次硬跑只验证英国能被连接并被请求；拒绝线作为后手存在。",
            operations=("OP-003",),
            terminal_hint="进入英国信用/秩序责任审计。",
        ),
        V04Branch(
            branch_id="BR-britain-interferes",
            trigger="英国干涉意大利奥匈海战",
            selected=False,
            reason="本次硬跑选择英国不干涉，验证不干涉状态可以由已连接槽位生成。",
            operations=("OP-006",),
            terminal_hint="若选择干涉，则意奥海战世界线进入英国外部干涉分支。",
        ),
        V04Branch(
            branch_id="BR-serbia-refuses-separation",
            trigger="塞尔维亚拒绝切割极端民族主义",
            selected=False,
            reason="本次硬跑只验证切割困境成立；拒绝线作为塞尔维亚后手分支。",
            operations=("OP-007",),
            terminal_hint="塞尔维亚失去程序道德位置。",
        ),
    )


def _apply_delta(states: dict[str, dict[str, Any]], operation: V04Operation) -> dict[str, dict[str, Any]]:
    new_states = deepcopy(states)
    for obj, delta in operation.state_delta.items():
        new_states.setdefault(obj, {})
        new_states[obj].update(delta)
    return new_states


def _diff_states(
    before: dict[str, dict[str, Any]],
    after: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    changes: list[dict[str, Any]] = []
    objects = sorted(set(before) | set(after))
    for obj in objects:
        before_obj = before.get(obj, {})
        after_obj = after.get(obj, {})
        keys = sorted(set(before_obj) | set(after_obj))
        for key in keys:
            old = before_obj.get(key, None)
            new = after_obj.get(key, None)
            if old != new:
                changes.append(
                    {
                        "object": obj,
                        "field": key,
                        "before": old,
                        "after": new,
                    }
                )
    return changes


def _selected_operations(operations: tuple[V04Operation, ...]) -> list[V04Operation]:
    return [operation for operation in operations if operation.selected]


def _choice_options_for_scene(
    scene_id: str,
    operations: tuple[V04Operation, ...],
    branches: tuple[V04Branch, ...],
) -> list[dict[str, Any]]:
    branch_by_op = {
        op_id: branch for branch in branches for op_id in branch.operations
    }
    options = []
    for operation in operations:
        if operation.scene_id != scene_id:
            continue
        branch = branch_by_op.get(operation.operation_id)
        options.append(
            {
                "operation_id": operation.operation_id,
                "svo": operation.svo,
                "selected": operation.selected,
                "domain_pack": operation.domain_pack,
                "dependencies": list(operation.dependencies),
                "state_delta": operation.state_delta,
                "branch_id": branch.branch_id if branch else operation.branch_if_uncooperative,
                "terminal_hint": branch.terminal_hint if branch else "",
            }
        )
    return options


def _timeline(
    operations: tuple[V04Operation, ...],
    branches: tuple[V04Branch, ...],
) -> list[dict[str, Any]]:
    states = _initial_object_states()
    timeline = [
        {
            "t": "T00",
            "scene_id": "SC-00",
            "event": "断面初始状态",
            "choice_prompt": "萨拉热窝刺杀后，各对象初始状态如何？",
            "operation_id": "",
            "operation_svo": "",
            "domain_pack": "",
            "dependencies": [],
            "choices": [],
            "state_changes": [],
            "object_states_before": deepcopy(states),
            "object_states_after": deepcopy(states),
        }
    ]
    for idx, operation in enumerate(_selected_operations(operations), start=1):
        before = deepcopy(states)
        after = _apply_delta(states, operation)
        timeline.append(
            {
                "t": f"T{idx:02d}",
                "scene_id": operation.scene_id,
                "event": operation.derived_from,
                "choice_prompt": operation.choice_prompt,
                "operation_id": operation.operation_id,
                "operation_svo": operation.svo,
                "domain_pack": operation.domain_pack,
                "dependencies": list(operation.dependencies),
                "branch_if_uncooperative": operation.branch_if_uncooperative,
                "choices": _choice_options_for_scene(operation.scene_id, operations, branches),
                "state_changes": _diff_states(before, after),
                "object_states_before": before,
                "object_states_after": after,
            }
        )
        states = after
    return timeline


def _movie_structure(timeline: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "format": "chooseable_movie_state_puzzle",
        "state_dimensions": list(STATE_DIMENSIONS),
        "initial_state_board": timeline[0]["object_states_after"],
        "scenes": [
            {
                "scene_id": node["scene_id"],
                "time": node["t"],
                "prompt": node["choice_prompt"],
                "selected_operation": node["operation_svo"],
                "choices": node["choices"],
                "state_changes": node["state_changes"],
            }
            for node in timeline[1:]
        ],
        "final_state_board": timeline[-1]["object_states_after"],
    }


def _final_settlement(timeline: list[dict[str, Any]]) -> dict[str, Any]:
    final_states = timeline[-1]["object_states_after"]
    return {
        "worldline_id": "WL-COMP-001",
        "terminal_state": final_states["austria_hungary"].get("terminal_state"),
        "objects_at_end": final_states,
        "terminal_effects": {
            "austria_hungary": "原史实吸引子在本 fixture 中被剥离。",
            "britain": "英国被请求进入观察位置，并生成对意奥海战不干涉状态。",
            "italy": "亚得里亚海战槽位成立，且该槽位没有被英国干涉。",
            "serbia": "塞尔维亚进入切割/拒绝切割的程序两难。",
            "russia": "俄国干净动员点被削弱。",
            "france": "法国支持俄国的成本上升。",
            "geography": "英吉利海峡与亚得里亚海两个地理连接均成立。",
        },
    }


def _synthetic_operation(
    *,
    operation_id: str,
    scene_id: str,
    s: str,
    v: str,
    o: str,
    derived_from: str,
    state_delta: dict[str, dict[str, Any]],
    domain_pack: str = "branch_operation_graph",
    dependencies: tuple[str, ...] = (),
) -> V04Operation:
    return V04Operation(
        operation_id=operation_id,
        scene_id=scene_id,
        source_stage=domain_pack,
        s=s,
        v=v,
        o=o,
        domain_pack=domain_pack,
        derived_from=derived_from,
        selected=True,
        choice_prompt=f"{scene_id} branch choice",
        dependencies=dependencies,
        state_delta=state_delta,
    )


def _variant_operations() -> dict[str, V04Operation]:
    return {
        "BR-UK-REFUSE-OP": _synthetic_operation(
            operation_id="BR-UK-REFUSE-OP",
            scene_id="SC-02B",
            s="Britain",
            v="refuses",
            o="observer role",
            derived_from="Britain refuses the observer role; the request remains recorded, but the observer state does not close.",
            state_delta={
                "britain": {
                    "british_observer_role": "refused",
                    "continental_order_responsibility": "refused",
                },
                "austria_hungary": {
                    "procedural_legitimacy": "observer_request_recorded_but_not_closed"
                },
                "france": {"support_to_russia": "less_constrained_by_britain"},
            },
        ),
        "BR-UK-INTERFERE-OP": _synthetic_operation(
            operation_id="BR-UK-INTERFERE-OP",
            scene_id="SC-05B",
            s="Britain",
            v="interferes",
            o="Italy-Austria-Hungary naval conflict",
            derived_from="Britain chooses interference instead of non-interference in the Italy-Austria-Hungary naval-conflict slot.",
            state_delta={
                "britain": {
                    "british_non_interference": "rejected",
                    "naval_interference": "declared",
                },
                "italy": {"adriatic_naval_conflict": "british_interfered"},
                "austria_hungary": {
                    "external_naval_interference_from_britain": "active"
                },
            },
        ),
        "BR-SERBIA-REFUSE-OP": _synthetic_operation(
            operation_id="BR-SERBIA-REFUSE-OP",
            scene_id="SC-06B",
            s="Serbia",
            v="refuses",
            o="separation from extremist nationalist network",
            derived_from="Serbia refuses the separation demand; the forced-choice node resolves into a refusal branch.",
            state_delta={
                "serbia": {
                    "serbian_nationalist_separation": "refused",
                    "procedural_position": "morally_weakened",
                },
                "austria_hungary": {
                    "procedural_legitimacy": "rising_from_serbian_refusal"
                },
            },
        ),
    }


def _operation_index(operations: tuple[V04Operation, ...]) -> dict[str, V04Operation]:
    return {operation.operation_id: operation for operation in operations}


def _terminal_variant_operation(
    *,
    worldline_id: str,
    terminal_state: str,
    terminal_kind: str,
    choice_signature: str,
) -> V04Operation:
    return _synthetic_operation(
        operation_id=f"TERM-{worldline_id}",
        scene_id="SC-99",
        s="world_tree",
        v="settles",
        o=worldline_id,
        domain_pack="world_tree_runtime",
        derived_from=f"World tree settles {worldline_id} as {terminal_kind}.",
        state_delta={
            "austria_hungary": {
                "austria_hungary_original_worldline_gravity": terminal_kind,
                "terminal_state": terminal_state,
            },
            "world_tree": {
                "terminal": worldline_id,
                "worldline_id": worldline_id,
                "choice_signature": choice_signature,
            },
        },
    )


def _timeline_from_selected(
    selected_operations: list[V04Operation],
    choice_operations: tuple[V04Operation, ...],
    branches: tuple[V04Branch, ...],
) -> list[dict[str, Any]]:
    states = _initial_object_states()
    timeline = [
        {
            "t": "T00",
            "scene_id": "SC-00",
            "event": "initial cross-section",
            "choice_prompt": "initial object state board",
            "operation_id": "",
            "operation_svo": "",
            "domain_pack": "",
            "dependencies": [],
            "choices": [],
            "state_changes": [],
            "object_states_before": deepcopy(states),
            "object_states_after": deepcopy(states),
        }
    ]
    for idx, operation in enumerate(selected_operations, start=1):
        before = deepcopy(states)
        after = _apply_delta(states, operation)
        timeline.append(
            {
                "t": f"T{idx:02d}",
                "scene_id": operation.scene_id,
                "event": operation.derived_from,
                "choice_prompt": operation.choice_prompt,
                "operation_id": operation.operation_id,
                "operation_svo": operation.svo,
                "domain_pack": operation.domain_pack,
                "dependencies": list(operation.dependencies),
                "branch_if_uncooperative": operation.branch_if_uncooperative,
                "choices": _choice_options_for_scene(
                    operation.scene_id, choice_operations, branches
                ),
                "state_changes": _diff_states(before, after),
                "object_states_before": before,
                "object_states_after": after,
            }
        )
        states = after
    return timeline


def _terminal_kind_from_choices(
    *,
    ultimatum_choice: str,
    observer_choice: str,
    naval_choice: str,
    serbia_choice: str,
) -> tuple[str, str]:
    if ultimatum_choice == "delay_pending":
        return "pending_dependency_terminal", "pending_temporal_dependency"
    if observer_choice == "britain_refuses":
        return "shadow_terminal", "escaped_but_observer_refused"
    if naval_choice == "britain_interferes":
        return "shadow_terminal", "escaped_but_britain_interfered"
    if serbia_choice == "serbia_refuses":
        return "shadow_terminal", "escaped_with_serbian_refusal_branch"
    return "closed_terminal", "non_original_worldline_terminal"


def _worldline_set(
    operations: tuple[V04Operation, ...],
    branches: tuple[V04Branch, ...],
) -> dict[str, Any]:
    op = _operation_index(operations)
    variants = _variant_operations()
    worldlines: list[dict[str, Any]] = []
    seen_signatures: set[str] = set()
    all_choice_operations = tuple((*operations, *variants.values()))
    choices = {
        "ultimatum": ("cancel", "delay_pending"),
        "observer": ("britain_observer_requested", "britain_refuses"),
        "naval": ("britain_non_interference", "britain_interferes"),
        "serbia": ("forced_choice", "serbia_refuses"),
    }
    counter = 1
    for ultimatum_choice in choices["ultimatum"]:
        for observer_choice in choices["observer"]:
            for naval_choice in choices["naval"]:
                for serbia_choice in choices["serbia"]:
                    signature = "|".join(
                        (ultimatum_choice, observer_choice, naval_choice, serbia_choice)
                    )
                    if signature in seen_signatures:
                        continue
                    seen_signatures.add(signature)
                    worldline_id = f"WL-COMP-{counter:03d}"
                    counter += 1

                    selected: list[V04Operation] = [
                        op["OP-001"] if ultimatum_choice == "cancel" else op["OP-002"],
                        op["OP-003"],
                    ]
                    if observer_choice == "britain_refuses":
                        selected.append(variants["BR-UK-REFUSE-OP"])
                    selected.extend((op["OP-004"], op["OP-005"]))
                    selected.append(
                        op["OP-006"]
                        if naval_choice == "britain_non_interference"
                        else variants["BR-UK-INTERFERE-OP"]
                    )
                    selected.append(op["OP-007"])
                    if serbia_choice == "serbia_refuses":
                        selected.append(variants["BR-SERBIA-REFUSE-OP"])
                    terminal_kind, terminal_state = _terminal_kind_from_choices(
                        ultimatum_choice=ultimatum_choice,
                        observer_choice=observer_choice,
                        naval_choice=naval_choice,
                        serbia_choice=serbia_choice,
                    )
                    selected.append(
                        _terminal_variant_operation(
                            worldline_id=worldline_id,
                            terminal_state=terminal_state,
                            terminal_kind=terminal_kind,
                            choice_signature=signature,
                        )
                    )
                    timeline = _timeline_from_selected(selected, all_choice_operations, branches)
                    final_states = timeline[-1]["object_states_after"]
                    worldlines.append(
                        {
                            "worldline_id": worldline_id,
                            "choice_signature": signature,
                            "choices": {
                                "ultimatum": ultimatum_choice,
                                "observer": observer_choice,
                                "naval": naval_choice,
                                "serbia": serbia_choice,
                            },
                            "terminal_kind": terminal_kind,
                            "terminal_state": terminal_state,
                            "node_count": len(timeline),
                            "timeline": timeline,
                            "final_state_board": final_states,
                            "state_change_count": sum(
                                len(node["state_changes"]) for node in timeline[1:]
                            ),
                        }
                    )
    by_terminal_kind: dict[str, int] = {}
    for worldline in worldlines:
        by_terminal_kind[worldline["terminal_kind"]] = (
            by_terminal_kind.get(worldline["terminal_kind"], 0) + 1
        )
    return {
        "mode": "bounded_cartesian_expansion_of_explicit_fixture_choices",
        "choice_axes": choices,
        "worldline_count": len(worldlines),
        "dedupe_policy": "choice_signature_unique",
        "deduped_count": len(seen_signatures),
        "by_terminal_kind": by_terminal_kind,
        "worldlines": worldlines,
    }


def _worldline_merge_ablation(worldline_set: dict[str, Any]) -> dict[str, Any]:
    worldlines = [
        item
        for item in worldline_set.get("worldlines", ())
        if isinstance(item, dict)
    ]
    raw_count = len(worldlines)
    terminal_groups: dict[str, list[dict[str, Any]]] = {}
    terminal_kind_groups: dict[str, int] = {}
    for worldline in worldlines:
        terminal_state = str(worldline.get("terminal_state", ""))
        terminal_kind = str(worldline.get("terminal_kind", ""))
        merge_key = f"{terminal_kind}::{terminal_state}"
        terminal_groups.setdefault(merge_key, []).append(worldline)
        terminal_kind_groups[terminal_kind] = terminal_kind_groups.get(terminal_kind, 0) + 1

    merged_representatives = []
    for merge_key, group in sorted(terminal_groups.items()):
        representative = group[0]
        merged_representatives.append(
            {
                "merge_key": merge_key,
                "representative_worldline_id": representative.get("worldline_id"),
                "terminal_kind": representative.get("terminal_kind"),
                "terminal_state": representative.get("terminal_state"),
                "merged_worldline_count": len(group),
                "merged_choice_signatures": [
                    item.get("choice_signature") for item in group
                ],
            }
        )

    merged_count = len(merged_representatives)
    duplicate_count = max(0, raw_count - merged_count)
    return {
        "ablation_name": "worldline_merge_rule",
        "merge_rule": "terminal_kind_and_terminal_state_equivalence",
        "without_merge_worldline_count": raw_count,
        "with_merge_worldline_count": merged_count,
        "duplicate_or_equivalent_worldline_count": duplicate_count,
        "compression_ratio": (raw_count / merged_count) if merged_count else None,
        "terminal_kind_count_without_merge": terminal_kind_groups,
        "terminal_kind_types_preserved": sorted(
            key for key in terminal_kind_groups if key
        ),
        "merged_representatives": merged_representatives,
        "interpretation": (
            "The ablation keeps the same bounded choice expansion but compares "
            "the raw worldline set against an equivalence merge by terminal "
            "kind and terminal state.  It shows whether the merge rule reduces "
            "inspection cost while preserving terminal outcome types."
        ),
    }


def build_v04_july1914_compliance_hard_run_response(
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    read_stage = _read_cross_section()
    senses = _fixture_senses()
    ingestion = _ingest_terms(tuple(read_stage["tokens"]), senses)
    operations = _generate_operations()
    branches = _branches()
    timeline = _timeline(operations, branches)
    worldline_set = _worldline_set(operations, branches)
    worldline_merge_ablation = _worldline_merge_ablation(worldline_set)
    terminal = timeline[-1]["object_states_after"]
    dependency_ledger = [
        {
            "id": "DEP-TIME-001",
            "kind": "timestamp_delta_required",
            "operation_id": "OP-002",
            "operation": "奥匈 延后 最后通牒",
            "missing_slot": "Δt",
            "status": "pending_not_selected",
            "expiry_coefficient": 0.0,
            "reason": "本次选择取消最后通牒，因此延后分支只挂账；若未来选择延后，必须补时间戳标准。",
        }
    ]
    checks = {
        "cross_section_read": bool(read_stage["tokens"]),
        "temporary_ingestion_done": len(ingestion["known_senses"]) >= 6,
        "svo_operations_generated": all(
            all(getattr(op, key) for key in ("s", "v", "o")) for op in operations
        ),
        "initial_state_board_complete": all(
            obj in timeline[0]["object_states_after"]
            for obj in (
                "austria_hungary",
                "britain",
                "serbia",
                "italy",
                "russia",
                "france",
                "germany",
                "geography",
            )
        ),
        "each_selected_scene_has_state_diff": all(
            node["state_changes"] for node in timeline[1:]
        ),
        "each_selected_scene_has_choices": all(node["choices"] for node in timeline[1:]),
        "geography_links_britain_to_continent": terminal["geography"].get(
            "britain_continent_link"
        )
        == "available",
        "geography_links_italy_ah_naval_zone": terminal["geography"].get(
            "adriatic_italy_ah_link"
        )
        == "available",
        "britain_non_interference_state_generated": terminal["britain"].get(
            "british_non_interference"
        )
        == "declared_for_italy_ah_naval_conflict",
        "serbia_dilemma_generated": terminal["serbia"].get("procedural_position")
        == "dilemma",
        "terminal_exits_original_worldline": terminal["austria_hungary"].get(
            "terminal_state"
        )
        == "non_original_worldline_terminal",
        "worldline_set_expanded": worldline_set["worldline_count"] == 16,
        "worldline_merge_ablation_preserves_terminal_types": set(
            worldline_merge_ablation["terminal_kind_types_preserved"]
        )
        == {"closed_terminal", "pending_dependency_terminal", "shadow_terminal"},
        "worldline_set_has_closed_shadow_and_pending": all(
            key in worldline_set["by_terminal_kind"]
            for key in ("closed_terminal", "shadow_terminal", "pending_dependency_terminal")
        ),
        "each_expanded_worldline_has_state_movie": all(
            item["timeline"]
            and item["final_state_board"]
            and item["state_change_count"] > 0
            for item in worldline_set["worldlines"]
        ),
    }
    return {
        "ok": all(checks.values()),
        "component": "v04_compliance_hard_run",
        "route": "/api/v04/july1914/compliance-hard-run",
        "scope": {
            "mode": "compliance_fixture_not_full_generation",
            "possibility_policy": "only_operations_named_in_current_v04_report",
            "selection_policy": (
                "generated_candidates_include_temporal_delay_but_selected_mainline_"
                "uses_cancel_ultimatum; unselected delay_stays_in_dependency_ledger"
            ),
            "goal": "produce_one_closed_worldline_with_per_object_timeline_states",
        },
        "pipeline": [
            read_stage,
            ingestion,
            {
                "stage": "runtime_lexicon_snapshot",
                "senses": [
                    {
                        "term": sense.term,
                        "pack": sense.pack,
                        "pos": sense.pos,
                        "slots": list(sense.slots),
                        "state_effects": sense.state_effects,
                        "temporary": sense.temporary,
                    }
                    for sense in senses
                ],
            },
            {
                "stage": "svo_operation_generation",
                "operations": [
                    {
                        "operation_id": op.operation_id,
                        "scene_id": op.scene_id,
                        "selected": op.selected,
                        "s": op.s,
                        "v": op.v,
                        "o": op.o,
                        "domain_pack": op.domain_pack,
                        "derived_from": op.derived_from,
                        "dependencies": list(op.dependencies),
                        "state_delta": op.state_delta,
                    }
                    for op in operations
                ],
            },
            {
                "stage": "branch_registration",
                "branches": [
                    {
                        "branch_id": branch.branch_id,
                        "trigger": branch.trigger,
                        "selected": branch.selected,
                        "reason": branch.reason,
                        "operations": list(branch.operations),
                        "terminal_hint": branch.terminal_hint,
                    }
                    for branch in branches
                ],
            },
            {
                "stage": "terminal_state",
                "worldline_id": "WL-COMP-001",
                "terminal_object_states": terminal,
            },
        ],
        "dependency_ledger": dependency_ledger,
        "timeline": timeline,
        "interactive_movie": _movie_structure(timeline),
        "worldline_set": worldline_set,
        "worldline_merge_ablation": worldline_merge_ablation,
        "final_settlement": _final_settlement(timeline),
        "checks": checks,
        "report_summary": {
            "worldline_id": "WL-COMP-001",
            "node_count": len(timeline),
            "generated_operation_count": len(operations),
            "selected_operation_count": len(_selected_operations(operations)),
            "expanded_worldline_count": worldline_set["worldline_count"],
            "result": (
                "本 fixture 已拼齐初始断面、每幕选择、每步对象状态变化和终止状态。"
                "英国不干涉意大利奥匈海战只是其中一个状态，不是唯一结论。"
            ),
        },
    }
