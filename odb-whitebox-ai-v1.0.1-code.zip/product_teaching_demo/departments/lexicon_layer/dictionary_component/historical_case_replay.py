from __future__ import annotations

"""Replay historical dynamic cases from explicit case JSON.

This module is a deterministic adapter for historical-case files such as the
July 1914 Austria-Hungary dynamic case.  It does not import the old G-drive
demo package and it does not copy prewritten report conclusions.  It rebuilds
the branch search from explicit initial metrics, action conditions, and action
effects.
"""

from dataclasses import asdict, dataclass, field, replace
import json
from pathlib import Path
from typing import Any, Literal

from state_graph_core import stable_id


SearchMode = Literal["normal", "desperate"]
ConditionOperator = Literal[">=", "<=", ">", "<", "=="]

DEFAULT_BENEFIT_METRICS: tuple[str, ...] = (
    "success_probability",
    "payoff",
    "survivability",
    "time_leverage",
    "narrative_control",
    "legitimacy",
    "entente_binding",
    "internal_cohesion",
)
DEFAULT_RISK_METRICS: tuple[str, ...] = (
    "fragility",
    "war_risk",
    "execution_complexity",
    "mobilization_threshold",
)


@dataclass(frozen=True)
class HistoricalCondition:
    metric: str
    operator: ConditionOperator
    value: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HistoricalCondition":
        operator = str(data.get("operator", ">="))
        if operator not in {">=", "<=", ">", "<", "=="}:
            raise ValueError(f"unsupported_historical_condition_operator:{operator}")
        return cls(
            metric=str(data["metric"]),
            operator=operator,  # type: ignore[arg-type]
            value=float(data["value"]),
        )

    def matches(self, metrics: dict[str, float]) -> bool:
        current = metrics.get(self.metric, 0.0)
        if self.operator == ">=":
            return current >= self.value
        if self.operator == "<=":
            return current <= self.value
        if self.operator == ">":
            return current > self.value
        if self.operator == "<":
            return current < self.value
        return current == self.value


@dataclass(frozen=True)
class HistoricalEffect:
    metric: str
    delta: float
    reason: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HistoricalEffect":
        return cls(
            metric=str(data["metric"]),
            delta=float(data["delta"]),
            reason=str(data.get("reason", "")),
        )


@dataclass(frozen=True)
class HistoricalAction:
    action_id: str
    name: str
    actor: str
    rationale: str
    effects: tuple[HistoricalEffect, ...]
    conditions: tuple[HistoricalCondition, ...] = ()
    tags: tuple[str, ...] = ()
    repeatable: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HistoricalAction":
        return cls(
            action_id=str(data["id"]),
            name=str(data.get("name", data["id"])),
            actor=str(data.get("actor", "unknown")),
            rationale=str(data.get("rationale", "")),
            effects=tuple(
                HistoricalEffect.from_dict(item)
                for item in data.get("effects", ())
                if isinstance(item, dict)
            ),
            conditions=tuple(
                HistoricalCondition.from_dict(item)
                for item in data.get("conditions", ())
                if isinstance(item, dict)
            ),
            tags=tuple(str(item) for item in data.get("tags", ())),
            repeatable=bool(data.get("repeatable", False)),
        )

    def is_available(self, state: "HistoricalState", used_action_ids: frozenset[str]) -> bool:
        if not self.repeatable and self.action_id in used_action_ids:
            return False
        return all(condition.matches(state.metrics) for condition in self.conditions)


@dataclass(frozen=True)
class HistoricalState:
    state_id: str
    depth: int
    time_label: str
    metrics: dict[str, float]
    notes: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HistoricalState":
        raw_metrics = data.get("metrics", {})
        if not isinstance(raw_metrics, dict):
            raise TypeError("historical_initial_state_metrics_must_be_dict")
        return cls(
            state_id=str(data.get("id", "initial")),
            depth=int(data.get("depth", 0)),
            time_label=str(data.get("time_label", "T0")),
            metrics={str(key): float(value) for key, value in raw_metrics.items()},
            notes=tuple(str(item) for item in data.get("notes", ())),
        )


@dataclass(frozen=True)
class HistoricalSearchConfig:
    max_depth: int = 3
    beam_width: int = 5
    prune_threshold: float = -999.0
    mode: SearchMode = "normal"
    score_weights: dict[str, float] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HistoricalSearchConfig":
        mode = str(data.get("mode", "normal"))
        if mode not in {"normal", "desperate"}:
            raise ValueError(f"unsupported_historical_search_mode:{mode}")
        return cls(
            max_depth=int(data.get("max_depth", 3)),
            beam_width=int(data.get("beam_width", 5)),
            prune_threshold=float(data.get("prune_threshold", -999.0)),
            mode=mode,  # type: ignore[arg-type]
            score_weights={
                str(key): float(value)
                for key, value in dict(
                    data.get("score_weights", data.get("scoring_weights", {}))
                ).items()
            },
        )


@dataclass(frozen=True)
class HistoricalCase:
    case_id: str
    title: str
    premise: str
    initial_state: HistoricalState
    actions: tuple[HistoricalAction, ...]
    config: HistoricalSearchConfig
    audit_nodes: tuple[dict[str, Any], ...] = ()
    terminal_conditions: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HistoricalCase":
        return cls(
            case_id=str(data["id"]),
            title=str(data.get("title", data["id"])),
            premise=str(data.get("premise", "")),
            initial_state=HistoricalState.from_dict(dict(data["initial_state"])),
            actions=tuple(
                HistoricalAction.from_dict(item)
                for item in data.get("actions", ())
                if isinstance(item, dict)
            ),
            config=HistoricalSearchConfig.from_dict(dict(data.get("config", {}))),
            audit_nodes=tuple(
                dict(item) for item in data.get("audit_nodes", ()) if isinstance(item, dict)
            ),
            terminal_conditions=tuple(str(item) for item in data.get("terminal_conditions", ())),
        )


@dataclass(frozen=True)
class HistoricalTransitionRecord:
    action: HistoricalAction
    before: HistoricalState
    after: HistoricalState
    explanations: tuple[str, ...]


@dataclass(frozen=True)
class HistoricalPath:
    path_id: str
    state: HistoricalState
    transitions: tuple[HistoricalTransitionRecord, ...]
    score: float
    used_action_ids: frozenset[str]

    @property
    def action_names(self) -> tuple[str, ...]:
        return tuple(transition.action.name for transition in self.transitions)


@dataclass(frozen=True)
class HistoricalPrunedPath:
    path: HistoricalPath
    reason: str


@dataclass(frozen=True)
class HistoricalReplayResult:
    ok: bool
    status: Literal["completed", "paused_missing_initial_metrics", "paused_missing_score_weights"]
    case: HistoricalCase
    surviving_paths: tuple[HistoricalPath, ...] = ()
    pruned_paths: tuple[HistoricalPrunedPath, ...] = ()
    pending_metric_requests: tuple[dict[str, Any], ...] = ()
    audit: dict[str, Any] = field(default_factory=dict)


def load_historical_case(path: Path) -> HistoricalCase:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise TypeError("historical_case_json_must_be_object")
    return HistoricalCase.from_dict(data)


def _required_metrics(
    case: HistoricalCase,
    score_weights: dict[str, float],
) -> tuple[str, ...]:
    metrics = set(case.initial_state.metrics)
    for action in case.actions:
        metrics.update(effect.metric for effect in action.effects)
        metrics.update(condition.metric for condition in action.conditions)
    metrics.update(score_weights)
    return tuple(sorted(metrics))


def _pending_metric_requests(
    case: HistoricalCase,
    missing_metrics: tuple[str, ...],
) -> tuple[dict[str, Any], ...]:
    return tuple(
        {
            "request_id": stable_id(
                "historical_case_metric_request",
                {"case_id": case.case_id, "metric": metric},
            ),
            "kind": "historical_initial_metric",
            "variable_key": f"initial_metric:{metric}",
            "metric": metric,
            "prompt": f"请输入历史案例初始指标 {metric} 的数值 / Supply initial metric {metric}",
            "input_schema": {
                "ui_kind": "number",
                "field": metric,
                "min": 0,
                "max": 10,
            },
        }
        for metric in missing_metrics
    )


def _pending_score_weight_request(case: HistoricalCase) -> tuple[dict[str, Any], ...]:
    metric_candidates = tuple(
        sorted(
            {
                *case.initial_state.metrics.keys(),
                *(effect.metric for action in case.actions for effect in action.effects),
                *(condition.metric for action in case.actions for condition in action.conditions),
            }
        )
    )
    return (
        {
            "request_id": stable_id(
                "historical_case_score_weight_request",
                {"case_id": case.case_id, "metric_candidates": metric_candidates},
            ),
            "kind": "historical_score_weights",
            "variable_key": "historical_case:score_weights",
            "metric_candidates": metric_candidates,
            "prompt": "请为历史案例评分函数提供显式指标权重 / Supply explicit metric score weights",
            "input_schema": {
                "ui_kind": "metric_weight_map",
                "field": "score_weights",
                "metric_candidates": metric_candidates,
            },
        },
    )


def _with_metric_inputs(
    case: HistoricalCase,
    metric_inputs: dict[str, Any],
) -> HistoricalCase:
    if not metric_inputs:
        return case
    metrics = dict(case.initial_state.metrics)
    for key, value in metric_inputs.items():
        metrics[str(key)] = float(value)
    return replace(
        case,
        initial_state=replace(case.initial_state, metrics=metrics),
    )


def run_historical_case_replay(
    case: HistoricalCase,
    *,
    initial_metric_inputs: dict[str, Any] | None = None,
    score_weights: dict[str, Any] | None = None,
) -> HistoricalReplayResult:
    resolved_case = _with_metric_inputs(case, dict(initial_metric_inputs or {}))
    resolved_score_weights = (
        {str(key): float(value) for key, value in score_weights.items()}
        if score_weights is not None
        else dict(resolved_case.config.score_weights)
    )
    audit = {
        "source_rule": "historical_case_json_initial_metrics_actions_conditions_effects_drive_replay",
        "uses_precomputed_report_paths": False,
        "uses_placeholder_metric_values": False,
        "uses_implicit_score_weights": False,
        "uses_implicit_zero_for_missing_score_metrics": False,
        "runtime_ai_used": False,
        "randomness_used": False,
        "action_count": len(resolved_case.actions),
    }
    if not resolved_score_weights:
        return HistoricalReplayResult(
            ok=False,
            status="paused_missing_score_weights",
            case=resolved_case,
            pending_metric_requests=_pending_score_weight_request(resolved_case),
            audit={
                **audit,
                "missing_score_weights": True,
                "score_weight_source": "must_be_case_config_or_human_api_payload",
            },
        )
    required = _required_metrics(resolved_case, resolved_score_weights)
    missing = tuple(metric for metric in required if metric not in resolved_case.initial_state.metrics)
    audit = {
        **audit,
        "required_metric_count": len(required),
        "score_weight_source": (
            "api_or_human_payload"
            if score_weights is not None
            else "case_config"
        ),
        "score_weights": dict(resolved_score_weights),
    }
    if missing:
        return HistoricalReplayResult(
            ok=False,
            status="paused_missing_initial_metrics",
            case=resolved_case,
            pending_metric_requests=_pending_metric_requests(resolved_case, missing),
            audit={**audit, "missing_metrics": missing},
        )

    initial_path = HistoricalPath(
        path_id="path_0",
        state=resolved_case.initial_state,
        transitions=(),
        score=_evaluate(resolved_case.initial_state.metrics, resolved_score_weights),
        used_action_ids=frozenset(),
    )
    frontier = (initial_path,)
    all_pruned: list[HistoricalPrunedPath] = []
    for _depth in range(resolved_case.config.max_depth):
        expanded: list[HistoricalPath] = []
        for path in frontier:
            actions = _available_actions(resolved_case.actions, path)
            if not actions:
                expanded.append(path)
            else:
                expanded.extend(_extend(path, action, resolved_score_weights) for action in actions)
        frontier, pruned = _prune(tuple(expanded), resolved_case.config)
        all_pruned.extend(pruned)

    surviving = tuple(sorted(frontier, key=lambda path: path.score, reverse=True))
    return HistoricalReplayResult(
        ok=True,
        status="completed",
        case=resolved_case,
        surviving_paths=surviving,
        pruned_paths=tuple(all_pruned),
        audit={
            **audit,
            "surviving_path_count": len(surviving),
            "pruned_path_count": len(all_pruned),
        },
    )


def _evaluate(metrics: dict[str, float], score_weights: dict[str, float]) -> float:
    missing = tuple(metric for metric in score_weights if metric not in metrics)
    if missing:
        raise ValueError(f"score_metric_missing_after_validation:{missing}")
    return sum(metrics[metric] * weight for metric, weight in score_weights.items())


def _available_actions(
    actions: tuple[HistoricalAction, ...],
    path: HistoricalPath,
) -> tuple[HistoricalAction, ...]:
    return tuple(
        action
        for action in actions
        if action.is_available(path.state, path.used_action_ids)
    )


def _extend(
    path: HistoricalPath,
    action: HistoricalAction,
    score_weights: dict[str, float],
) -> HistoricalPath:
    after, explanations = _transition(path.state, action)
    transition = HistoricalTransitionRecord(
        action=action,
        before=path.state,
        after=after,
        explanations=explanations,
    )
    used = frozenset((*path.used_action_ids, action.action_id))
    return HistoricalPath(
        path_id=f"{path.path_id}.{action.action_id}",
        state=after,
        transitions=(*path.transitions, transition),
        score=_evaluate(after.metrics, score_weights),
        used_action_ids=used,
    )


def _transition(
    state: HistoricalState,
    action: HistoricalAction,
) -> tuple[HistoricalState, tuple[str, ...]]:
    metrics = dict(state.metrics)
    explanations: list[str] = []
    for effect in action.effects:
        if effect.metric not in metrics:
            raise ValueError(f"effect_metric_missing_after_validation:{effect.metric}")
        old_value = metrics[effect.metric]
        new_value = _clamp(old_value + effect.delta)
        metrics[effect.metric] = new_value
        direction = "raises" if effect.delta >= 0 else "lowers"
        reason = f": {effect.reason}" if effect.reason else ""
        explanations.append(
            f"{action.name} {direction} {effect.metric} "
            f"from {old_value:.1f} to {new_value:.1f}{reason}"
        )
    after = replace(
        state,
        state_id=f"{state.state_id}->{action.action_id}",
        depth=state.depth + 1,
        time_label=f"T{state.depth + 1}",
        metrics=metrics,
        notes=(*state.notes, action.rationale),
    )
    return after, tuple(explanations)


def _prune(
    paths: tuple[HistoricalPath, ...],
    config: HistoricalSearchConfig,
) -> tuple[tuple[HistoricalPath, ...], tuple[HistoricalPrunedPath, ...]]:
    ranked = tuple(sorted(paths, key=lambda path: path.score, reverse=True))
    kept = [
        path
        for path in ranked
        if path.score >= config.prune_threshold
    ][: config.beam_width]
    kept_ids = {path.path_id for path in kept}
    if config.mode == "desperate":
        candidates = tuple(
            path
            for path in ranked
            if path.path_id not in kept_ids and _is_longshot_candidate(path)
        )
        if candidates:
            longshot = max(
                candidates,
                key=lambda path: (
                    path.state.metrics.get("payoff", 0.0),
                    path.state.metrics.get("time_leverage", 0.0),
                ),
            )
            kept.append(longshot)
            kept_ids.add(longshot.path_id)
    pruned = tuple(
        HistoricalPrunedPath(path=path, reason=_prune_reason(path, kept_ids, config))
        for path in ranked
        if path.path_id not in kept_ids
    )
    return tuple(kept), pruned


def _is_longshot_candidate(path: HistoricalPath) -> bool:
    if path.state.metrics.get("payoff", 0.0) >= 8:
        return True
    if (
        path.state.metrics.get("time_leverage", 0.0) >= 7
        and path.state.metrics.get("narrative_control", 0.0) >= 6
    ):
        return True
    return any(
        "longshot" in transition.action.tags
        or "high_payoff" in transition.action.tags
        for transition in path.transitions
    )


def _prune_reason(
    path: HistoricalPath,
    kept_ids: set[str],
    config: HistoricalSearchConfig,
) -> str:
    if path.score < config.prune_threshold:
        return "score below prune threshold"
    metrics = path.state.metrics
    if metrics.get("fragility", 0.0) >= 8:
        return "fragility too high under current mode"
    if metrics.get("war_risk", 0.0) >= 8:
        return "war risk too high under current mode"
    if metrics.get("payoff", 0.0) < 4:
        return "payoff too low"
    return "outside beam width"


def _clamp(value: float) -> float:
    return max(0.0, min(10.0, value))


def _path_to_dict(path: HistoricalPath) -> dict[str, Any]:
    return {
        "path_id": path.path_id,
        "score": path.score,
        "action_ids": tuple(transition.action.action_id for transition in path.transitions),
        "action_names": path.action_names,
        "final_metrics": dict(path.state.metrics),
        "transitions": tuple(
            {
                "action_id": transition.action.action_id,
                "action_name": transition.action.name,
                "actor": transition.action.actor,
                "before_metrics": dict(transition.before.metrics),
                "after_metrics": dict(transition.after.metrics),
                "explanations": transition.explanations,
                "rationale": transition.action.rationale,
            }
            for transition in path.transitions
        ),
        "why_it_wins": _why_it_wins(path),
        "why_it_loses": _why_it_loses(path),
    }


def _why_it_wins(path: HistoricalPath) -> tuple[str, ...]:
    metrics = path.state.metrics
    reasons: list[str] = []
    if metrics.get("time_leverage", 0.0) >= 7:
        reasons.append("It creates enough time leverage for later weights to shift.")
    if metrics.get("narrative_control", 0.0) >= 7:
        reasons.append("It controls the explanatory frame before rivals settle one.")
    if metrics.get("legitimacy", 0.0) >= 7:
        reasons.append("It gains public legitimacy without forcing a total settlement.")
    if metrics.get("entente_binding", 0.0) >= 6:
        reasons.append("It pulls Britain or France into an observation frame.")
    if metrics.get("internal_cohesion", 0.0) >= 6:
        reasons.append("It keeps enough internal command coherence to act.")
    if metrics.get("survivability", 0.0) >= 7:
        reasons.append("Even failure leaves a recoverable position.")
    if metrics.get("payoff", 0.0) >= 8:
        reasons.append("The payoff is high enough to justify longshot retention.")
    return tuple(reasons or ["It survives pruning under the configured search mode."])


def _why_it_loses(path: HistoricalPath) -> tuple[str, ...]:
    metrics = path.state.metrics
    reasons: list[str] = []
    if metrics.get("fragility", 0.0) >= 7:
        reasons.append("It depends on several low-confidence assumptions at once.")
    if metrics.get("war_risk", 0.0) >= 7:
        reasons.append("It may trigger uncontrolled military escalation.")
    if metrics.get("mobilization_threshold", 0.0) >= 7:
        reasons.append("It may cross the mobilization threshold and hand escalation to others.")
    if metrics.get("execution_complexity", 0.0) >= 7:
        reasons.append("It may exceed the actor's coordination capacity.")
    if metrics.get("success_probability", 0.0) < 4:
        reasons.append("Its direct success probability remains low.")
    return tuple(reasons or ["No dominant failure mechanism is visible in current metrics."])


def historical_replay_result_to_dict(result: HistoricalReplayResult) -> dict[str, Any]:
    return {
        "ok": result.ok,
        "status": result.status,
        "component": "historical_case_replay",
        "case": {
            "case_id": result.case.case_id,
            "title": result.case.title,
            "premise": result.case.premise,
            "initial_state": asdict(result.case.initial_state),
            "config": asdict(result.case.config),
            "action_count": len(result.case.actions),
            "terminal_conditions": result.case.terminal_conditions,
        },
        "pending_metric_requests": result.pending_metric_requests,
        "surviving_paths": tuple(_path_to_dict(path) for path in result.surviving_paths),
        "pruned_paths": tuple(
            {
                "path_id": item.path.path_id,
                "action_names": item.path.action_names,
                "score": item.path.score,
                "reason": item.reason,
            }
            for item in result.pruned_paths[:50]
        ),
        "audit": result.audit,
    }
