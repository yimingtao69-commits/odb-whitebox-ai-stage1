"""Internalized dictionary/state-graph component workstations."""

