from __future__ import annotations

from dataclasses import asdict
from typing import Any

from .canonical import stable_id
from .models import (
    ActionInvocation,
    ActionSchema,
    ConditionEvaluation,
    DomainPack,
    EntityRef,
    ExecutionEvent,
    ExecutionResult,
    Scalar,
    ScenarioIR,
    StateEffect,
    StateFact,
    StatePredicate,
    StateTransition,
)


_MISSING = object()


class SemanticIRValidationError(ValueError):
    pass


def state_key(entity_id: str, dimension: str, binding_entity_id: str = "") -> str:
    if not entity_id or not dimension:
        raise SemanticIRValidationError("state_key_requires_entity_and_dimension")
    return ":".join(part for part in (entity_id, dimension, binding_entity_id) if part)


def _source_ids(pack: DomainPack, scenario: ScenarioIR) -> set[str]:
    return {item.source_id for item in (*pack.sources, *scenario.sources)}


def _validate_scenario(pack: DomainPack, scenario: ScenarioIR) -> None:
    if scenario.semantic_ir_version != "1.0":
        raise SemanticIRValidationError(
            f"unsupported_semantic_ir_version:{scenario.semantic_ir_version}"
        )
    if scenario.domain_pack_id != pack.pack_id or scenario.domain_pack_version != pack.version:
        raise SemanticIRValidationError("scenario_domain_pack_identity_mismatch")
    if scenario.mode != "intervention" and scenario.interventions:
        raise SemanticIRValidationError("interventions_require_intervention_mode")
    entities = {item.entity_id: item for item in scenario.entities}
    if len(entities) != len(scenario.entities):
        raise SemanticIRValidationError("duplicate_entity_id")
    sources = _source_ids(pack, scenario)
    for entity in scenario.entities:
        if entity.entity_type not in pack.entity_types:
            raise SemanticIRValidationError(
                f"entity_type_not_allowed:{entity.entity_id}:{entity.entity_type}"
            )
        if entity.source_id not in sources:
            raise SemanticIRValidationError(f"entity_unknown_source:{entity.entity_id}")
    for fact in (*scenario.initial_state, *scenario.interventions):
        if fact.entity_id not in entities or (
            fact.binding_entity_id and fact.binding_entity_id not in entities
        ):
            raise SemanticIRValidationError("state_fact_references_unknown_entity")
        if fact.source_id not in sources:
            raise SemanticIRValidationError("state_fact_references_unknown_source")
    action_ids = {item.action_id for item in pack.actions}
    for invocation in scenario.actions:
        if invocation.action_id not in action_ids:
            raise SemanticIRValidationError(
                f"unknown_action:{invocation.invocation_id}:{invocation.action_id}"
            )
        if invocation.source_id not in sources:
            raise SemanticIRValidationError(
                f"invocation_unknown_source:{invocation.invocation_id}"
            )
        if any(entity_id not in entities for entity_id in invocation.role_bindings.values()):
            raise SemanticIRValidationError(
                f"invocation_unknown_entity:{invocation.invocation_id}"
            )


def _resolve_state_id(
    role_bindings: dict[str, str],
    entity_role: str,
    dimension: str,
    binding_role: str,
) -> str:
    try:
        entity_id = role_bindings[entity_role]
        binding_entity_id = role_bindings[binding_role] if binding_role else ""
    except KeyError as exc:
        raise SemanticIRValidationError(f"unbound_action_role:{exc.args[0]}") from exc
    return state_key(entity_id, dimension, binding_entity_id)


def _predicate_matches(predicate: StatePredicate, actual: Any) -> bool:
    if predicate.operator == "exists":
        return actual is not _MISSING
    if actual is _MISSING:
        return False
    if predicate.operator == "equals":
        return actual == predicate.expected
    if predicate.operator == "not_equals":
        return actual != predicate.expected
    if predicate.operator == "gte":
        return isinstance(actual, (int, float)) and isinstance(
            predicate.expected, (int, float)
        ) and actual >= predicate.expected
    if predicate.operator == "lte":
        return isinstance(actual, (int, float)) and isinstance(
            predicate.expected, (int, float)
        ) and actual <= predicate.expected
    raise AssertionError(f"unhandled_predicate_operator:{predicate.operator}")


def _baseline_assumption_value(predicate: StatePredicate) -> Scalar | object:
    if predicate.operator in {"equals", "gte", "lte"}:
        return predicate.expected
    return _MISSING


def _apply_effect(effect: StateEffect, before: Any) -> Scalar:
    if effect.operation == "set":
        return effect.value
    if not isinstance(before, (int, float)) or not isinstance(effect.value, (int, float)):
        raise SemanticIRValidationError(
            f"numeric_effect_requires_numeric_state:{effect.operation}"
        )
    if effect.operation == "increment":
        return before + effect.value
    if effect.operation == "decrement":
        return before - effect.value
    raise AssertionError(f"unhandled_effect_operation:{effect.operation}")


def _schema_by_id(pack: DomainPack) -> dict[str, ActionSchema]:
    return {item.action_id: item for item in pack.actions}


def _validate_invocation_roles(
    invocation: ActionInvocation,
    schema: ActionSchema,
) -> tuple[str, ...]:
    missing = tuple(role for role in schema.required_roles if role not in invocation.role_bindings)
    extra = tuple(role for role in invocation.role_bindings if role not in schema.roles)
    return tuple(
        [*(f"missing_role:{role}" for role in missing), *(f"unknown_role:{role}" for role in extra)]
    )


def execute_scenario(pack: DomainPack, scenario: ScenarioIR) -> ExecutionResult:
    """Execute a typed scenario without domain-specific branches or runtime AI."""

    _validate_scenario(pack, scenario)
    state: dict[str, Scalar] = {}
    state_sources: dict[str, str] = {}
    for fact in scenario.initial_state:
        key = state_key(fact.entity_id, fact.dimension, fact.binding_entity_id)
        if key in state:
            raise SemanticIRValidationError(f"duplicate_initial_state:{key}")
        state[key] = fact.value
        state_sources[key] = fact.source_id
    initial_state = dict(state)
    if scenario.mode == "intervention":
        for fact in scenario.interventions:
            key = state_key(fact.entity_id, fact.dimension, fact.binding_entity_id)
            state[key] = fact.value
            state_sources[key] = fact.source_id

    schemas = _schema_by_id(pack)
    assumptions: list[StateFact] = []
    events: list[ExecutionEvent] = []
    for invocation in scenario.actions:
        schema = schemas[invocation.action_id]
        blocked_reasons = list(_validate_invocation_roles(invocation, schema))
        conditions: list[ConditionEvaluation] = []
        for predicate in schema.preconditions:
            key = _resolve_state_id(
                invocation.role_bindings,
                predicate.entity_role,
                predicate.dimension,
                predicate.binding_role,
            )
            actual = state.get(key, _MISSING)
            if actual is _MISSING and scenario.mode == "baseline":
                assumption_value = _baseline_assumption_value(predicate)
                if assumption_value is not _MISSING:
                    entity_id = invocation.role_bindings[predicate.entity_role]
                    binding_entity_id = (
                        invocation.role_bindings[predicate.binding_role]
                        if predicate.binding_role
                        else ""
                    )
                    assumption = StateFact(
                        entity_id=entity_id,
                        dimension=predicate.dimension,
                        value=assumption_value,  # type: ignore[arg-type]
                        source_id=predicate.source_id,
                        binding_entity_id=binding_entity_id,
                    )
                    assumptions.append(assumption)
                    state[key] = assumption.value
                    state_sources[key] = assumption.source_id
                    actual = assumption.value
                    status = "assumed"
                else:
                    status = "missing"
                    blocked_reasons.append(f"missing_state:{key}")
            elif actual is _MISSING:
                status = "missing"
                blocked_reasons.append(f"missing_state:{key}")
            elif _predicate_matches(predicate, actual):
                status = "satisfied"
            else:
                status = "conflict"
                blocked_reasons.append(f"state_conflict:{key}")
            conditions.append(
                ConditionEvaluation(
                    state_id=key,
                    operator=predicate.operator,
                    expected=predicate.expected,
                    actual=None if actual is _MISSING else actual,
                    status=status,  # type: ignore[arg-type]
                    source_id=predicate.source_id,
                )
            )

        transitions: list[StateTransition] = []
        if blocked_reasons:
            status = "blocked"
        elif schema.execution_policy == "record_only":
            status = "recorded"
        else:
            status = "completed"
            for effect in schema.effects:
                key = _resolve_state_id(
                    invocation.role_bindings,
                    effect.entity_role,
                    effect.dimension,
                    effect.binding_role,
                )
                before = state.get(key, _MISSING)
                if before is _MISSING and effect.operation != "set":
                    raise SemanticIRValidationError(f"numeric_effect_missing_state:{key}")
                after = _apply_effect(effect, None if before is _MISSING else before)
                transitions.append(
                    StateTransition(
                        state_id=key,
                        operation=effect.operation,
                        before_value=None if before is _MISSING else before,
                        after_value=after,
                        source_id=effect.source_id,
                    )
                )
                state[key] = after
                state_sources[key] = effect.source_id
        event_payload = {
            "scenario_id": scenario.scenario_id,
            "invocation": asdict(invocation),
            "conditions": tuple(asdict(item) for item in conditions),
            "transitions": tuple(asdict(item) for item in transitions),
            "status": status,
        }
        events.append(
            ExecutionEvent(
                event_id=stable_id("event", event_payload),
                invocation_id=invocation.invocation_id,
                action_id=invocation.action_id,
                status=status,  # type: ignore[arg-type]
                conditions=tuple(conditions),
                transitions=tuple(transitions),
                source_id=invocation.source_id,
                blocked_reasons=tuple(blocked_reasons),
            )
        )
        if blocked_reasons:
            break

    ok = len(events) == len(scenario.actions) and all(
        event.status in {"completed", "recorded"} for event in events
    )
    audit = {
        "runtime_ai_used": False,
        "randomness_used": False,
        "domain_specific_branching_in_engine": False,
        "provenance_required": True,
        "domain_pack_fingerprint": pack.metadata.get("domain_pack_fingerprint", ""),
        "event_count": len(events),
        "assumption_count": len(assumptions),
        "intervention_count": len(scenario.interventions),
    }
    result_payload = {
        "scenario_id": scenario.scenario_id,
        "pack": (pack.pack_id, pack.version),
        "mode": scenario.mode,
        "final_state": state,
        "events": events,
        "assumptions": assumptions,
        "interventions": scenario.interventions,
    }
    return ExecutionResult(
        ok=ok,
        scenario_id=scenario.scenario_id,
        semantic_ir_version=scenario.semantic_ir_version,
        domain_pack_id=pack.pack_id,
        domain_pack_version=pack.version,
        mode=scenario.mode,
        initial_state=initial_state,
        final_state=dict(state),
        final_state_sources=dict(state_sources),
        events=tuple(events),
        assumptions=tuple(assumptions),
        interventions=scenario.interventions,
        audit=audit,
        result_id=stable_id("result", result_payload),
    )
