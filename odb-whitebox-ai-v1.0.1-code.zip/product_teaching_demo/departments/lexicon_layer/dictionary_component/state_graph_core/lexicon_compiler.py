from __future__ import annotations

from dataclasses import asdict

from .canonical import stable_id
from .sense_dependency_resolver import (
    ExpandedSense,
    SenseDependencyResolutionError,
    resolve_sense_dependencies,
)
from .models import (
    ActionSchema,
    ArticleDomainRanking,
    DomainHitEvidence,
    DomainPack,
    DomainScore,
    LexiconPack,
    LexiconSense,
    ScannedLexicalTerm,
    SourceRef,
)


class LexiconCompilationError(ValueError):
    pass


CONTENT_PARTS_OF_SPEECH = {"noun", "noun_phrase", "verb", "adjective"}


def rank_domains_for_terms(
    packs: tuple[LexiconPack, ...],
    terms: tuple[ScannedLexicalTerm, ...],
) -> ArticleDomainRanking:
    """Rank domains by sourced lexical hits across the fully scanned article."""

    evidence: list[DomainHitEvidence] = []
    counts: dict[str, int] = {}
    first_hit: dict[str, int] = {}
    evidence_ids: dict[str, list[str]] = {}
    for term in terms:
        if term.part_of_speech not in CONTENT_PARTS_OF_SPEECH:
            continue
        normalized = term.lemma.strip().lower()
        matches_by_domain: dict[str, list[tuple[LexiconPack, LexiconSense, str]]] = {}
        for pack in packs:
            for sense in pack.senses:
                lemma = sense.lemma.lower()
                aliases = {item.lower() for item in sense.aliases}
                if normalized == lemma:
                    match_kind = "lemma"
                elif normalized in aliases:
                    match_kind = "alias"
                else:
                    continue
                for domain in sense.domains:
                    matches_by_domain.setdefault(domain, []).append(
                        (pack, sense, match_kind)
                    )
        for domain, matches in sorted(matches_by_domain.items()):
            evidence_id = stable_id(
                "domain_hit",
                {
                    "occurrence_index": term.occurrence_index,
                    "lemma": normalized,
                    "domain": domain,
                    "sense_ids": tuple(sorted(item[1].sense_id for item in matches)),
                },
            )
            match_kinds = {item[2] for item in matches}
            evidence.append(DomainHitEvidence(
                evidence_id=evidence_id,
                occurrence_index=term.occurrence_index,
                surface=term.surface,
                lemma=normalized,
                part_of_speech=term.part_of_speech,
                domain=domain,
                match_kind=(
                    next(iter(match_kinds))
                    if len(match_kinds) == 1
                    else "multiple_lexical_match_kinds"
                ),
                pack_ids=tuple(sorted({item[0].pack_id for item in matches})),
                sense_ids=tuple(sorted({item[1].sense_id for item in matches})),
                source_ids=tuple(sorted({item[1].source_id for item in matches})),
            ))
            counts[domain] = counts.get(domain, 0) + 1
            first_hit.setdefault(domain, term.occurrence_index)
            evidence_ids.setdefault(domain, []).append(evidence_id)
    scores = tuple(
        DomainScore(
            domain=domain,
            hit_count=counts[domain],
            first_hit_index=first_hit[domain],
            evidence_ids=tuple(evidence_ids[domain]),
        )
        for domain in sorted(
            counts,
            key=lambda item: (-counts[item], first_hit[item], item),
        )
    )
    return ArticleDomainRanking(
        domain_order=tuple(item.domain for item in scores),
        scores=scores,
        evidence=tuple(evidence),
        source_rule=(
            "content_word_occurrence_hits_in_lexicon_packs_count_once_per_domain_"
            "then_sort_by_count_desc_first_hit_asc_domain_id_asc"
        ),
    )


def select_senses_by_domain_order(
    packs: tuple[LexiconPack, ...],
    lemma: str,
    domain_order: tuple[str, ...],
    part_of_speech: str = "",
) -> tuple[LexiconSense, ...]:
    """Try word senses in the article-derived domain order."""

    normalized = lemma.strip().lower()
    domain_rank = {domain: index for index, domain in enumerate(domain_order)}
    candidates = tuple(
        sense
        for pack in packs
        for sense in pack.senses
        if normalized in {sense.lemma.lower(), *(alias.lower() for alias in sense.aliases)}
        and (not part_of_speech or part_of_speech == sense.part_of_speech)
        and (not domain_order or any(domain in domain_rank for domain in sense.domains))
    )
    return tuple(sorted(
        candidates,
        key=lambda sense: (
            min(
                (domain_rank[domain] for domain in sense.domains if domain in domain_rank),
                default=len(domain_rank),
            ),
            -sense.priority,
            sense.sense_id,
        ),
    ))


def select_senses(
    pack: LexiconPack,
    lemma: str,
    domain: str = "",
    part_of_speech: str = "",
) -> tuple[LexiconSense, ...]:
    normalized = lemma.strip().lower()
    candidates = [
        sense
        for sense in pack.senses
        if normalized in {sense.lemma.lower(), *(alias.lower() for alias in sense.aliases)}
        and (not domain or domain in sense.domains)
        and (not part_of_speech or part_of_speech == sense.part_of_speech)
    ]
    return tuple(sorted(candidates, key=lambda item: (-item.priority, item.sense_id)))


def action_schema_from_lexicon_sense(sense: LexiconSense) -> ActionSchema:
    action_id = sense.action_id or sense.sense_id
    roles = tuple(role.role for role in sense.roles)
    required_roles = tuple(role.role for role in sense.roles if role.required)
    return ActionSchema(
        action_id=action_id,
        roles=roles,
        required_roles=required_roles,
        preconditions=sense.preconditions,
        effects=sense.effects,
        source_id=sense.source_id,
        execution_policy=sense.execution_policy,
    )


def _dedupe_packs(packs: tuple[LexiconPack, ...]) -> tuple[LexiconPack, ...]:
    unique: dict[str, LexiconPack] = {}
    for pack in packs:
        unique.setdefault(pack.pack_id, pack)
    return tuple(unique.values())


def _expanded_action_schema(
    sense: LexiconSense,
    expanded: ExpandedSense,
) -> ActionSchema:
    return ActionSchema(
        action_id=sense.action_id or sense.sense_id,
        roles=tuple(role.role for role in sense.roles),
        required_roles=tuple(role.role for role in sense.roles if role.required),
        preconditions=expanded.preconditions,
        effects=expanded.effects,
        source_id=sense.source_id,
        execution_policy=sense.execution_policy,
    )


def compile_lexicon_pack_to_domain_pack(
    pack: LexiconPack,
    domain: str,
    pack_id: str | None = None,
    dependency_packs: tuple[LexiconPack, ...] = (),
) -> DomainPack:
    """Compile selected lexical senses to the existing execution schema.

    This adapter is deliberately narrow: it does not invent workflow rules.
    It only turns chosen word senses into action schemas that the generic
    state executor already understands.
    """

    selected = tuple(sense for sense in pack.senses if domain in sense.domains)
    if not selected:
        raise LexiconCompilationError(f"no_senses_for_domain:{domain}")
    all_dependency_packs = _dedupe_packs((pack, *dependency_packs))
    executable_senses = tuple(
        sense
        for sense in selected
        if sense.part_of_speech == "verb"
        and (
            sense.action_id
            or sense.roles
            or sense.preconditions
            or sense.effects
        )
    )
    compiled_expansions: list[dict[str, object]] = []
    actions: list[ActionSchema] = []
    for sense in executable_senses:
        try:
            expanded = resolve_sense_dependencies(
                all_dependency_packs,
                sense.sense_id,
                root_pack_id=pack.pack_id,
                domain_order=(domain,),
            )
        except SenseDependencyResolutionError as exc:
            raise LexiconCompilationError(
                f"sense_dependency_resolution_failed:{sense.sense_id}:{exc}"
            ) from exc
        if expanded.conflicts:
            raise LexiconCompilationError(
                f"sense_dependency_conflict:{sense.sense_id}:{len(expanded.conflicts)}"
            )
        actions.append(_expanded_action_schema(sense, expanded))
        compiled_expansions.append(
            {
                "sense_id": sense.sense_id,
                "action_id": sense.action_id or sense.sense_id,
                "expanded_sense_ids": expanded.expanded_sense_ids,
                "expanded_sense_refs": expanded.audit["expanded_sense_refs"],
                "trace": tuple(asdict(step) for step in expanded.trace),
                "precondition_count": len(expanded.preconditions),
                "effect_count": len(expanded.effects),
                "source_rule": expanded.audit["source_rule"],
            }
        )
    actions = tuple(actions)
    action_ids = [item.action_id for item in actions]
    if len(action_ids) != len(set(action_ids)):
        raise LexiconCompilationError(f"duplicate_action_id_after_lexicon_compile:{domain}")
    compiled_pack_id = pack_id or f"{pack.pack_id}:{domain}:compiled_actions"
    source_index: dict[str, SourceRef] = {}
    for source in (*pack.sources, *(source for dep_pack in dependency_packs for source in dep_pack.sources)):
        source_index.setdefault(source.source_id, source)
    compiled_sources = (
        *source_index.values(),
        SourceRef(
            source_id=f"lexicon_compile:{pack.pack_id}:{domain}",
            kind="lexicon_to_action_schema_compile",
            locator="state_graph_core/lexicon_compiler.py",
            excerpt="word senses lazily expanded then compiled to executable action schemas",
        ),
    )
    return DomainPack(
        pack_id=compiled_pack_id,
        version=pack.version,
        entity_types=pack.entity_types,
        actions=actions,
        sources=compiled_sources,
        metadata={
            "compiled_from_lexicon_pack_id": pack.pack_id,
            "compiled_from_lexicon_pack_version": pack.version,
            "domain": domain,
            "sense_count": len(selected),
            "executable_sense_count": len(executable_senses),
            "dependency_pack_ids": tuple(
                pack_item.pack_id for pack_item in all_dependency_packs if pack_item.pack_id != pack.pack_id
            ),
            "compressed_sense_expansions": tuple(compiled_expansions),
            "source_layer": "lexicon_pack",
            "contains_business_rules": False,
            "domain_pack_fingerprint": stable_id(
                "domainpack",
                {
                    "pack_id": compiled_pack_id,
                    "version": pack.version,
                    "domain": domain,
                    "senses": tuple(sense.sense_id for sense in selected),
                },
            ),
        },
    )
