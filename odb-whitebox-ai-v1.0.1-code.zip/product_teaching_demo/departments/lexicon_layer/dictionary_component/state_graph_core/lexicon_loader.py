from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .canonical import stable_id
from .domain_loader import _require_text, _strings
from .models import (
    LexiconPack,
    LexiconSense,
    SenseRole,
    SourceRef,
    StateEffect,
    StatePredicate,
)


class LexiconPackValidationError(ValueError):
    pass


_ALLOWED_PARTS_OF_SPEECH = {"verb", "noun", "adjective", "adverb", "modal", "preposition"}
_ALLOWED_OPERATORS = {"equals", "not_equals", "gte", "lte", "exists"}
_ALLOWED_OPERATIONS = {"set", "increment", "decrement"}
_ALLOWED_EXECUTION_POLICIES = {"execute", "record_only"}
_FORBIDDEN_RULE_FIELDS = {
    "business_rules",
    "rules",
    "triggers",
    "if_then_rules",
    "workflow_rules",
}


def _reject_rule_fields(record: dict[str, Any], location: str) -> None:
    forbidden = sorted(_FORBIDDEN_RULE_FIELDS.intersection(record))
    if forbidden:
        raise LexiconPackValidationError(
            f"{location}:lexicon_pack_must_not_embed_business_rules:{','.join(forbidden)}"
        )


def _validate_source(source_id: str, known_sources: set[str], location: str) -> None:
    if source_id not in known_sources:
        raise LexiconPackValidationError(f"{location}:unknown_source:{source_id}")


def _optional_strings(value: Any, location: str) -> tuple[str, ...]:
    if value is None:
        return ()
    return _strings(value, location)


def _predicate_from_dict(
    predicate: dict[str, Any],
    roles: set[str],
    known_sources: set[str],
    location: str,
) -> StatePredicate:
    entity_role = _require_text(predicate, "entity_role", location)
    binding_role = str(predicate.get("binding_role", ""))
    if entity_role not in roles or (binding_role and binding_role not in roles):
        raise LexiconPackValidationError(f"{location}:unknown_role")
    operator = _require_text(predicate, "operator", location)
    if operator not in _ALLOWED_OPERATORS:
        raise LexiconPackValidationError(f"{location}:invalid_operator:{operator}")
    source_id = _require_text(predicate, "source_id", location)
    _validate_source(source_id, known_sources, location)
    return StatePredicate(
        entity_role=entity_role,
        dimension=_require_text(predicate, "dimension", location),
        operator=operator,  # type: ignore[arg-type]
        expected=predicate.get("expected"),
        source_id=source_id,
        binding_role=binding_role,
    )


def _effect_from_dict(
    effect: dict[str, Any],
    roles: set[str],
    known_sources: set[str],
    location: str,
) -> StateEffect:
    entity_role = _require_text(effect, "entity_role", location)
    binding_role = str(effect.get("binding_role", ""))
    if entity_role not in roles or (binding_role and binding_role not in roles):
        raise LexiconPackValidationError(f"{location}:unknown_role")
    operation = _require_text(effect, "operation", location)
    if operation not in _ALLOWED_OPERATIONS:
        raise LexiconPackValidationError(f"{location}:invalid_operation:{operation}")
    source_id = _require_text(effect, "source_id", location)
    _validate_source(source_id, known_sources, location)
    return StateEffect(
        entity_role=entity_role,
        dimension=_require_text(effect, "dimension", location),
        operation=operation,  # type: ignore[arg-type]
        value=effect.get("value"),
        source_id=source_id,
        binding_role=binding_role,
    )


def lexicon_pack_from_dict(data: dict[str, Any]) -> LexiconPack:
    if not isinstance(data, dict):
        raise LexiconPackValidationError("lexicon_pack_must_be_object")
    _reject_rule_fields(data, "lexicon_pack")
    pack_id = _require_text(data, "pack_id", "lexicon_pack")
    version = _require_text(data, "version", "lexicon_pack")
    language = _require_text(data, "language", "lexicon_pack")
    entity_types = _strings(data.get("entity_types"), "lexicon_pack.entity_types")
    semantic_classes = _strings(
        data.get("semantic_classes"), "lexicon_pack.semantic_classes"
    )

    raw_sources = data.get("sources")
    if not isinstance(raw_sources, list) or not raw_sources:
        raise LexiconPackValidationError("lexicon_pack.sources:expected_nonempty_list")
    sources = tuple(
        SourceRef(
            source_id=_require_text(item, "source_id", f"sources[{index}]"),
            kind=_require_text(item, "kind", f"sources[{index}]"),
            locator=str(item.get("locator", "")),
            excerpt=str(item.get("excerpt", "")),
        )
        for index, item in enumerate(raw_sources)
        if isinstance(item, dict)
    )
    if len(sources) != len(raw_sources):
        raise LexiconPackValidationError("lexicon_pack.sources:entry_must_be_object")
    known_sources = {item.source_id for item in sources}
    if len(known_sources) != len(sources):
        raise LexiconPackValidationError("lexicon_pack.sources:duplicate_source_id")

    raw_senses = data.get("senses")
    if not isinstance(raw_senses, list) or not raw_senses:
        raise LexiconPackValidationError("lexicon_pack.senses:expected_nonempty_list")
    senses: list[LexiconSense] = []
    for sense_index, item in enumerate(raw_senses):
        location = f"senses[{sense_index}]"
        if not isinstance(item, dict):
            raise LexiconPackValidationError(f"{location}:entry_must_be_object")
        _reject_rule_fields(item, location)
        part_of_speech = _require_text(item, "part_of_speech", location)
        if part_of_speech not in _ALLOWED_PARTS_OF_SPEECH:
            raise LexiconPackValidationError(
                f"{location}:invalid_part_of_speech:{part_of_speech}"
            )
        semantic_class = _require_text(item, "semantic_class", location)
        if semantic_class not in semantic_classes:
            raise LexiconPackValidationError(f"{location}:unknown_semantic_class")
        source_id = _require_text(item, "source_id", location)
        _validate_source(source_id, known_sources, location)
        domains = _strings(item.get("domains"), f"{location}.domains")
        raw_roles = item.get("roles")
        if not isinstance(raw_roles, list) or not raw_roles:
            raise LexiconPackValidationError(f"{location}.roles:expected_nonempty_list")
        roles: list[SenseRole] = []
        for role_index, role in enumerate(raw_roles):
            role_location = f"{location}.roles[{role_index}]"
            if not isinstance(role, dict):
                raise LexiconPackValidationError(f"{role_location}:entry_must_be_object")
            role_types = _strings(role.get("semantic_types"), f"{role_location}.semantic_types")
            if any(entity_type not in entity_types for entity_type in role_types):
                raise LexiconPackValidationError(f"{role_location}:unknown_semantic_type")
            roles.append(
                SenseRole(
                    role=_require_text(role, "role", role_location),
                    semantic_types=role_types,
                    required=bool(role.get("required", True)),
                )
            )
        role_names = [item.role for item in roles]
        if len(role_names) != len(set(role_names)):
            raise LexiconPackValidationError(f"{location}.roles:duplicate_role")
        role_set = set(role_names)

        preconditions = tuple(
            _predicate_from_dict(predicate, role_set, known_sources, f"{location}.preconditions[{index}]")
            for index, predicate in enumerate(item.get("preconditions", []))
            if isinstance(predicate, dict)
        )
        if len(preconditions) != len(item.get("preconditions", [])):
            raise LexiconPackValidationError(f"{location}.preconditions:entry_must_be_object")
        effects = tuple(
            _effect_from_dict(effect, role_set, known_sources, f"{location}.effects[{index}]")
            for index, effect in enumerate(item.get("effects", []))
            if isinstance(effect, dict)
        )
        if len(effects) != len(item.get("effects", [])):
            raise LexiconPackValidationError(f"{location}.effects:entry_must_be_object")
        execution_policy = str(item.get("execution_policy", "execute"))
        if execution_policy not in _ALLOWED_EXECUTION_POLICIES:
            raise LexiconPackValidationError(f"{location}:invalid_execution_policy")
        priority = item.get("priority", 0)
        if not isinstance(priority, int):
            raise LexiconPackValidationError(f"{location}:priority_must_be_integer")
        metadata = item.get("metadata", {})
        if not isinstance(metadata, dict):
            raise LexiconPackValidationError(f"{location}.metadata:must_be_object")
        senses.append(
            LexiconSense(
                sense_id=_require_text(item, "sense_id", location),
                lemma=_require_text(item, "lemma", location),
                part_of_speech=part_of_speech,  # type: ignore[arg-type]
                domains=domains,
                semantic_class=semantic_class,
                roles=tuple(roles),
                preconditions=preconditions,
                effects=effects,
                source_id=source_id,
                aliases=_optional_strings(item.get("aliases"), f"{location}.aliases"),
                disambiguation_cues=_optional_strings(
                    item.get("disambiguation_cues"),
                    f"{location}.disambiguation_cues",
                ),
                priority=priority,
                action_id=str(item.get("action_id", "")),
                execution_policy=execution_policy,  # type: ignore[arg-type]
                metadata=metadata,
            )
        )
    sense_ids = [item.sense_id for item in senses]
    if len(sense_ids) != len(set(sense_ids)):
        raise LexiconPackValidationError("lexicon_pack.senses:duplicate_sense_id")
    metadata = data.get("metadata", {})
    if not isinstance(metadata, dict):
        raise LexiconPackValidationError("lexicon_pack.metadata:must_be_object")
    metadata = {
        **metadata,
        "lexicon_pack_fingerprint": stable_id(
            "lexiconpack",
            {key: value for key, value in data.items() if key != "metadata"},
        ),
        "contains_business_rules": False,
    }
    return LexiconPack(
        pack_id=pack_id,
        version=version,
        language=language,
        entity_types=entity_types,
        semantic_classes=semantic_classes,
        senses=tuple(senses),
        sources=sources,
        metadata=metadata,
    )


def load_lexicon_pack(path: Path) -> LexiconPack:
    data = json.loads(path.read_text(encoding="utf-8"))
    return lexicon_pack_from_dict(data)
