from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .canonical import stable_id
from .models import (
    ActionSchema,
    DomainPack,
    SourceRef,
    StateEffect,
    StatePredicate,
)


class DomainPackValidationError(ValueError):
    pass


def _require_text(record: dict[str, Any], field: str, location: str) -> str:
    value = record.get(field)
    if not isinstance(value, str) or not value.strip():
        raise DomainPackValidationError(f"{location}:missing_text:{field}")
    return value.strip()


def _strings(value: Any, location: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not all(isinstance(item, str) and item for item in value):
        raise DomainPackValidationError(f"{location}:expected_nonempty_string_list")
    if len(value) != len(set(value)):
        raise DomainPackValidationError(f"{location}:duplicate_values")
    return tuple(value)


def _validate_source(source_id: str, known_sources: set[str], location: str) -> None:
    if source_id not in known_sources:
        raise DomainPackValidationError(f"{location}:unknown_source:{source_id}")


def domain_pack_from_dict(data: dict[str, Any]) -> DomainPack:
    if not isinstance(data, dict):
        raise DomainPackValidationError("domain_pack_must_be_object")
    pack_id = _require_text(data, "pack_id", "domain_pack")
    version = _require_text(data, "version", "domain_pack")
    entity_types = _strings(data.get("entity_types"), "domain_pack.entity_types")

    raw_sources = data.get("sources")
    if not isinstance(raw_sources, list) or not raw_sources:
        raise DomainPackValidationError("domain_pack.sources:expected_nonempty_list")
    sources = tuple(
        SourceRef(
            source_id=_require_text(item, "source_id", f"sources[{index}]"),
            kind=_require_text(item, "kind", f"sources[{index}]"),
            locator=str(item.get("locator", "")),
            excerpt=str(item.get("excerpt", "")),
        )
        for index, item in enumerate(raw_sources)
        if isinstance(item, dict)
    )
    if len(sources) != len(raw_sources):
        raise DomainPackValidationError("domain_pack.sources:entry_must_be_object")
    known_sources = {item.source_id for item in sources}
    if len(known_sources) != len(sources):
        raise DomainPackValidationError("domain_pack.sources:duplicate_source_id")

    raw_actions = data.get("actions")
    if not isinstance(raw_actions, list) or not raw_actions:
        raise DomainPackValidationError("domain_pack.actions:expected_nonempty_list")
    actions: list[ActionSchema] = []
    for action_index, item in enumerate(raw_actions):
        location = f"actions[{action_index}]"
        if not isinstance(item, dict):
            raise DomainPackValidationError(f"{location}:entry_must_be_object")
        action_id = _require_text(item, "action_id", location)
        roles = _strings(item.get("roles"), f"{location}.roles")
        required_roles = _strings(item.get("required_roles"), f"{location}.required_roles")
        if not set(required_roles).issubset(roles):
            raise DomainPackValidationError(f"{location}:required_role_not_declared")
        action_source_id = _require_text(item, "source_id", location)
        _validate_source(action_source_id, known_sources, location)

        preconditions: list[StatePredicate] = []
        for predicate_index, predicate in enumerate(item.get("preconditions", [])):
            predicate_location = f"{location}.preconditions[{predicate_index}]"
            if not isinstance(predicate, dict):
                raise DomainPackValidationError(f"{predicate_location}:entry_must_be_object")
            entity_role = _require_text(predicate, "entity_role", predicate_location)
            binding_role = str(predicate.get("binding_role", ""))
            if entity_role not in roles or (binding_role and binding_role not in roles):
                raise DomainPackValidationError(f"{predicate_location}:unknown_role")
            source_id = _require_text(predicate, "source_id", predicate_location)
            _validate_source(source_id, known_sources, predicate_location)
            operator = _require_text(predicate, "operator", predicate_location)
            if operator not in {"equals", "not_equals", "gte", "lte", "exists"}:
                raise DomainPackValidationError(f"{predicate_location}:invalid_operator:{operator}")
            preconditions.append(
                StatePredicate(
                    entity_role=entity_role,
                    dimension=_require_text(predicate, "dimension", predicate_location),
                    operator=operator,  # type: ignore[arg-type]
                    expected=predicate.get("expected"),
                    source_id=source_id,
                    binding_role=binding_role,
                )
            )

        effects: list[StateEffect] = []
        for effect_index, effect in enumerate(item.get("effects", [])):
            effect_location = f"{location}.effects[{effect_index}]"
            if not isinstance(effect, dict):
                raise DomainPackValidationError(f"{effect_location}:entry_must_be_object")
            entity_role = _require_text(effect, "entity_role", effect_location)
            binding_role = str(effect.get("binding_role", ""))
            if entity_role not in roles or (binding_role and binding_role not in roles):
                raise DomainPackValidationError(f"{effect_location}:unknown_role")
            source_id = _require_text(effect, "source_id", effect_location)
            _validate_source(source_id, known_sources, effect_location)
            operation = _require_text(effect, "operation", effect_location)
            if operation not in {"set", "increment", "decrement"}:
                raise DomainPackValidationError(f"{effect_location}:invalid_operation:{operation}")
            effects.append(
                StateEffect(
                    entity_role=entity_role,
                    dimension=_require_text(effect, "dimension", effect_location),
                    operation=operation,  # type: ignore[arg-type]
                    value=effect.get("value"),
                    source_id=source_id,
                    binding_role=binding_role,
                )
            )
        execution_policy = str(item.get("execution_policy", "execute"))
        if execution_policy not in {"execute", "record_only"}:
            raise DomainPackValidationError(f"{location}:invalid_execution_policy")
        actions.append(
            ActionSchema(
                action_id=action_id,
                roles=roles,
                required_roles=required_roles,
                preconditions=tuple(preconditions),
                effects=tuple(effects),
                source_id=action_source_id,
                execution_policy=execution_policy,  # type: ignore[arg-type]
            )
        )
    action_ids = [item.action_id for item in actions]
    if len(action_ids) != len(set(action_ids)):
        raise DomainPackValidationError("domain_pack.actions:duplicate_action_id")
    metadata = data.get("metadata", {})
    if not isinstance(metadata, dict):
        raise DomainPackValidationError("domain_pack.metadata:must_be_object")
    metadata = {
        **metadata,
        "domain_pack_fingerprint": stable_id(
            "domainpack",
            {key: value for key, value in data.items() if key != "metadata"},
        ),
    }
    return DomainPack(
        pack_id=pack_id,
        version=version,
        entity_types=entity_types,
        actions=tuple(actions),
        sources=sources,
        metadata=metadata,
    )


def load_domain_pack(path: Path) -> DomainPack:
    data = json.loads(path.read_text(encoding="utf-8"))
    return domain_pack_from_dict(data)
