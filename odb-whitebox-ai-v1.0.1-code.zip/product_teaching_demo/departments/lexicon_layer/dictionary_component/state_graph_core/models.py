from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


Scalar = str | int | float | bool | None
ExecutionMode = Literal["strict", "baseline", "intervention"]
PredicateOperator = Literal["equals", "not_equals", "gte", "lte", "exists"]
EffectOperation = Literal["set", "increment", "decrement"]
ExecutionPolicy = Literal["execute", "record_only"]
ConditionStatus = Literal["satisfied", "assumed", "missing", "conflict"]
EventStatus = Literal["completed", "recorded", "blocked"]
PartOfSpeech = Literal["verb", "noun", "adjective", "adverb", "modal", "preposition"]


@dataclass(frozen=True)
class SourceRef:
    source_id: str
    kind: str
    locator: str = ""
    excerpt: str = ""


@dataclass(frozen=True)
class EntityRef:
    entity_id: str
    entity_type: str
    label: str
    source_id: str


@dataclass(frozen=True)
class StateFact:
    entity_id: str
    dimension: str
    value: Scalar
    source_id: str
    binding_entity_id: str = ""


@dataclass(frozen=True)
class StatePredicate:
    entity_role: str
    dimension: str
    operator: PredicateOperator
    expected: Scalar
    source_id: str
    binding_role: str = ""


@dataclass(frozen=True)
class StateEffect:
    entity_role: str
    dimension: str
    operation: EffectOperation
    value: Scalar
    source_id: str
    binding_role: str = ""


@dataclass(frozen=True)
class ActionSchema:
    action_id: str
    roles: tuple[str, ...]
    required_roles: tuple[str, ...]
    preconditions: tuple[StatePredicate, ...]
    effects: tuple[StateEffect, ...]
    source_id: str
    execution_policy: ExecutionPolicy = "execute"


@dataclass(frozen=True)
class DomainPack:
    pack_id: str
    version: str
    entity_types: tuple[str, ...]
    actions: tuple[ActionSchema, ...]
    sources: tuple[SourceRef, ...]
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SenseRole:
    role: str
    semantic_types: tuple[str, ...]
    required: bool = True


@dataclass(frozen=True)
class LexiconSense:
    sense_id: str
    lemma: str
    part_of_speech: PartOfSpeech
    domains: tuple[str, ...]
    semantic_class: str
    roles: tuple[SenseRole, ...]
    preconditions: tuple[StatePredicate, ...]
    effects: tuple[StateEffect, ...]
    source_id: str
    aliases: tuple[str, ...] = ()
    disambiguation_cues: tuple[str, ...] = ()
    priority: int = 0
    action_id: str = ""
    execution_policy: ExecutionPolicy = "execute"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class LexiconPack:
    pack_id: str
    version: str
    language: str
    entity_types: tuple[str, ...]
    semantic_classes: tuple[str, ...]
    senses: tuple[LexiconSense, ...]
    sources: tuple[SourceRef, ...]
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ScannedLexicalTerm:
    occurrence_index: int
    surface: str
    lemma: str
    part_of_speech: PartOfSpeech


@dataclass(frozen=True)
class DomainHitEvidence:
    evidence_id: str
    occurrence_index: int
    surface: str
    lemma: str
    part_of_speech: PartOfSpeech
    domain: str
    match_kind: str
    pack_ids: tuple[str, ...]
    sense_ids: tuple[str, ...]
    source_ids: tuple[str, ...]


@dataclass(frozen=True)
class DomainScore:
    domain: str
    hit_count: int
    first_hit_index: int
    evidence_ids: tuple[str, ...]


@dataclass(frozen=True)
class ArticleDomainRanking:
    domain_order: tuple[str, ...]
    scores: tuple[DomainScore, ...]
    evidence: tuple[DomainHitEvidence, ...]
    source_rule: str


@dataclass(frozen=True)
class ActionInvocation:
    invocation_id: str
    action_id: str
    role_bindings: dict[str, str]
    source_id: str


@dataclass(frozen=True)
class ScenarioIR:
    scenario_id: str
    domain_pack_id: str
    domain_pack_version: str
    mode: ExecutionMode
    entities: tuple[EntityRef, ...]
    initial_state: tuple[StateFact, ...]
    actions: tuple[ActionInvocation, ...]
    sources: tuple[SourceRef, ...]
    interventions: tuple[StateFact, ...] = ()
    semantic_ir_version: str = "1.0"


@dataclass(frozen=True)
class ConditionEvaluation:
    state_id: str
    operator: PredicateOperator
    expected: Scalar
    actual: Scalar
    status: ConditionStatus
    source_id: str


@dataclass(frozen=True)
class StateTransition:
    state_id: str
    operation: EffectOperation
    before_value: Scalar
    after_value: Scalar
    source_id: str


@dataclass(frozen=True)
class ExecutionEvent:
    event_id: str
    invocation_id: str
    action_id: str
    status: EventStatus
    conditions: tuple[ConditionEvaluation, ...]
    transitions: tuple[StateTransition, ...]
    source_id: str
    blocked_reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class ExecutionResult:
    ok: bool
    scenario_id: str
    semantic_ir_version: str
    domain_pack_id: str
    domain_pack_version: str
    mode: ExecutionMode
    initial_state: dict[str, Scalar]
    final_state: dict[str, Scalar]
    final_state_sources: dict[str, str]
    events: tuple[ExecutionEvent, ...]
    assumptions: tuple[StateFact, ...]
    interventions: tuple[StateFact, ...]
    audit: dict[str, Any]
    result_id: str
