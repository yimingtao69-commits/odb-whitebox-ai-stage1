from __future__ import annotations

"""Lazy expansion for compressed lexicon senses.

Lexicon senses may store semantic compression in metadata instead of repeating
all lower-level conditions/effects.  For example, a historical phrase can point
to compressed person, state, geography, time, military, and diplomacy senses.
The resolver expands those links only when a reasoning layer asks for the
bottom-level predicates/effects.
"""

from dataclasses import dataclass
from typing import Any

from .models import LexiconPack, LexiconSense, StateEffect, StatePredicate


class SenseDependencyResolutionError(ValueError):
    pass


@dataclass(frozen=True)
class SenseDependencyStep:
    sense_id: str
    depth: int
    relation: str
    pack_id: str = ""
    via_domain: str = ""


@dataclass(frozen=True)
class SenseDependencyRef:
    sense_id: str
    pack_id: str = ""


@dataclass(frozen=True)
class SenseConflict:
    conflict_type: str
    key: tuple[str, str, str, str]
    first_sense_id: str
    first_value: Any
    second_sense_id: str
    second_value: Any


@dataclass(frozen=True)
class ExpandedSense:
    root_sense_id: str
    expanded_sense_ids: tuple[str, ...]
    preconditions: tuple[StatePredicate, ...]
    effects: tuple[StateEffect, ...]
    trace: tuple[SenseDependencyStep, ...]
    conflicts: tuple[SenseConflict, ...]
    audit: dict[str, Any]


def _sense_indexes(
    packs: tuple[LexiconPack, ...],
) -> tuple[dict[tuple[str, str], LexiconSense], dict[str, tuple[str, ...]]]:
    by_qualified: dict[tuple[str, str], LexiconSense] = {}
    packs_by_sense: dict[str, list[str]] = {}
    for pack in packs:
        for sense in pack.senses:
            key = (pack.pack_id, sense.sense_id)
            if key in by_qualified:
                raise SenseDependencyResolutionError(
                    f"duplicate_sense_id_inside_pack:{pack.pack_id}:{sense.sense_id}"
                )
            by_qualified[key] = sense
            packs_by_sense.setdefault(sense.sense_id, []).append(pack.pack_id)
    return by_qualified, {
        sense_id: tuple(sorted(pack_ids))
        for sense_id, pack_ids in packs_by_sense.items()
    }


def _dependency_refs_from_value(value: Any) -> tuple[SenseDependencyRef, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        return (SenseDependencyRef(value),) if value else ()
    if isinstance(value, dict):
        sense_id = str(value.get("sense_id", value.get("id", ""))).strip()
        if not sense_id:
            return ()
        return (
            SenseDependencyRef(
                sense_id=sense_id,
                pack_id=str(value.get("pack_id", value.get("pack", ""))).strip(),
            ),
        )
    if isinstance(value, (list, tuple)):
        refs: list[SenseDependencyRef] = []
        for item in value:
            refs.extend(_dependency_refs_from_value(item))
        return tuple(refs)
    text = str(value).strip()
    return (SenseDependencyRef(text),) if text else ()


def _dependency_ids(
    sense: LexiconSense,
    *,
    domain_order: tuple[str, ...],
) -> tuple[tuple[str, str, str], ...]:
    """Return (dependency_ref, relation, via_domain) dependencies in expansion order."""

    dependencies: list[tuple[SenseDependencyRef, str, str]] = []
    containers = [sense.metadata]
    compression = sense.metadata.get("definition_compression", {})
    if isinstance(compression, dict):
        containers.append(compression)
    seen = set()
    for container in containers:
        for ref in _dependency_refs_from_value(
            container.get("based_on", container.get("based_on_sense_ids"))
        ):
            key = (ref.pack_id, ref.sense_id)
            if key not in seen:
                dependencies.append((ref, "based_on", ""))
                seen.add(key)
    for container in containers:
        by_domain = container.get("based_on_by_domain", {})
        if not isinstance(by_domain, dict):
            continue
        ordered_domains = (
            *domain_order,
            *tuple(str(item) for item in by_domain if item not in domain_order),
        )
        for domain in ordered_domains:
            for ref in _dependency_refs_from_value(by_domain.get(domain)):
                key = (ref.pack_id, ref.sense_id)
                if key not in seen:
                    dependencies.append((ref, "based_on_by_domain", str(domain)))
                    seen.add(key)
    return tuple(dependencies)


def _resolve_ref(
    ref: SenseDependencyRef,
    by_qualified: dict[tuple[str, str], LexiconSense],
    packs_by_sense: dict[str, tuple[str, ...]],
) -> tuple[str, LexiconSense]:
    if ref.pack_id:
        key = (ref.pack_id, ref.sense_id)
        sense = by_qualified.get(key)
        if sense is None:
            raise SenseDependencyResolutionError(
                f"unknown_dependency_sense_ref:{ref.pack_id}:{ref.sense_id}"
            )
        return ref.pack_id, sense
    pack_ids = packs_by_sense.get(ref.sense_id, ())
    if not pack_ids:
        raise SenseDependencyResolutionError(f"unknown_dependency_sense_id:{ref.sense_id}")
    if len(pack_ids) > 1:
        raise SenseDependencyResolutionError(
            f"ambiguous_unqualified_sense_id:{ref.sense_id}:{','.join(pack_ids)}"
        )
    pack_id = pack_ids[0]
    return pack_id, by_qualified[(pack_id, ref.sense_id)]


def resolve_sense_dependencies(
    packs: tuple[LexiconPack, ...],
    root_sense_id: str,
    *,
    root_pack_id: str = "",
    domain_order: tuple[str, ...] = (),
) -> ExpandedSense:
    by_qualified, packs_by_sense = _sense_indexes(packs)
    root_pack_id, root_sense = _resolve_ref(
        SenseDependencyRef(root_sense_id, root_pack_id),
        by_qualified,
        packs_by_sense,
    )
    expanded_ids: list[str] = []
    expanded_refs: list[dict[str, str]] = []
    trace: list[SenseDependencyStep] = []
    preconditions: list[tuple[str, StatePredicate]] = []
    effects: list[tuple[str, StateEffect]] = []

    def visit(ref: SenseDependencyRef, stack: tuple[str, ...], depth: int, relation: str, via_domain: str = "") -> None:
        pack_id, sense = _resolve_ref(ref, by_qualified, packs_by_sense)
        qualified_id = f"{pack_id}:{sense.sense_id}"
        if qualified_id in stack:
            cycle = "->".join((*stack, qualified_id))
            raise SenseDependencyResolutionError(f"sense_dependency_cycle:{cycle}")
        trace.append(
            SenseDependencyStep(
                sense_id=sense.sense_id,
                pack_id=pack_id,
                depth=depth,
                relation=relation,
                via_domain=via_domain,
            )
        )
        for child_ref, child_relation, child_domain in _dependency_ids(
            sense,
            domain_order=domain_order,
        ):
            visit(child_ref, (*stack, qualified_id), depth + 1, child_relation, child_domain)
        if qualified_id not in {f"{item['pack_id']}:{item['sense_id']}" for item in expanded_refs}:
            expanded_ids.append(sense.sense_id)
            expanded_refs.append({"pack_id": pack_id, "sense_id": sense.sense_id})
        preconditions.extend((qualified_id, item) for item in sense.preconditions)
        effects.extend((qualified_id, item) for item in sense.effects)

    visit(SenseDependencyRef(root_sense.sense_id, root_pack_id), (), 0, "root")
    conflicts = _detect_conflicts(preconditions, effects)
    return ExpandedSense(
        root_sense_id=root_sense_id,
        expanded_sense_ids=tuple(expanded_ids),
        preconditions=tuple(item for _, item in preconditions),
        effects=tuple(item for _, item in effects),
        trace=tuple(trace),
        conflicts=conflicts,
        audit={
            "source_rule": "lexicon_sense_dependencies_are_lazily_expanded_on_reasoning_request",
            "root_sense_id": root_sense_id,
            "root_pack_id": root_pack_id,
            "expanded_sense_refs": tuple(expanded_refs),
            "domain_order": domain_order,
            "expanded_sense_count": len(expanded_ids),
            "conflict_count": len(conflicts),
            "stores_compressed_references_in_lexicon": True,
            "dependency_refs_can_identify_source_pack": True,
            "expands_only_when_requested_by_reasoning": True,
        },
    )


def _predicate_key(predicate: StatePredicate) -> tuple[str, str, str, str]:
    return (
        predicate.entity_role,
        predicate.dimension,
        predicate.binding_role,
        predicate.operator,
    )


def _effect_key(effect: StateEffect) -> tuple[str, str, str, str]:
    return (
        effect.entity_role,
        effect.dimension,
        effect.binding_role,
        effect.operation,
    )


def _detect_conflicts(
    preconditions: list[tuple[str, StatePredicate]],
    effects: list[tuple[str, StateEffect]],
) -> tuple[SenseConflict, ...]:
    conflicts: list[SenseConflict] = []
    seen_predicates: dict[tuple[str, str, str, str], tuple[str, Any]] = {}
    for sense_id, predicate in preconditions:
        key = _predicate_key(predicate)
        value = predicate.expected
        prior = seen_predicates.get(key)
        if prior is not None and prior[1] != value:
            conflicts.append(
                SenseConflict("precondition_conflict", key, prior[0], prior[1], sense_id, value)
            )
        else:
            seen_predicates[key] = (sense_id, value)

    seen_effects: dict[tuple[str, str, str, str], tuple[str, Any]] = {}
    for sense_id, effect in effects:
        key = _effect_key(effect)
        value = effect.value
        prior = seen_effects.get(key)
        if prior is not None and prior[1] != value:
            conflicts.append(
                SenseConflict("effect_conflict", key, prior[0], prior[1], sense_id, value)
            )
        else:
            seen_effects[key] = (sense_id, value)
    return tuple(conflicts)
